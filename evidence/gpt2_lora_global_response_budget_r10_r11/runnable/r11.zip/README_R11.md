# r11 frozen untouched-seed confirmation

r11 freezes the complete r10 current-refresh-1 versus source-frozen comparison
under four global response balls. No budget, step, chart, warm-start, LoRA or
backtracking setting is changed. The only substantive change is five untouched
seeds: 27211, 27217, 27229, 27241 and 27253.

Confirmation requires at least three of four budgets to have a positive paired
median and at least 4/5 current-positive seeds, while every numerical and global
budget gate passes. A failed scientific gate exits with code 2 after preserving
the full result archive.

Run `COLAB_LAUNCHER_R11.py --quick` only as an environment smoke test. Restart
the runtime and omit `--quick` for the frozen confirmation. Expected A100 time
is approximately 10-18 minutes.
