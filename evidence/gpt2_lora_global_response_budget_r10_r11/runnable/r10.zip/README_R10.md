# r10 matched global-response-budget Pareto audit

r9 matched per-step response changes but source-frozen accumulated roughly 377x
more drift from the warm response. r10 removes that confound. Current refresh-1
and source-frozen identity updates must remain inside the same global response
balls B = 5e-5, 1e-4, 2e-4 and 5e-4 at every accepted step. Proposals that
leave the ball are backtracked; a non-admissible proposal becomes a zero step.

This deliberately reuses development seeds. Current must win at at least three
of four budgets, with positive paired median and at least 4/5 positive seeds at
each supporting budget, to nominate an untouched-seed confirmation candidate.

Run `COLAB_LAUNCHER_R10.py --quick` first, then omit `--quick`. Expected A100
runtime is approximately 8-15 minutes.
