#!/usr/bin/env python3
"""Static checks that do not load GPT-2."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
cfg = json.loads((ROOT / "config_audit.json").read_text(encoding="utf-8"))
freeze = json.loads((ROOT / "PROTOCOL_FREEZE.json").read_text(encoding="utf-8"))
assert cfg["protocol"] == freeze["protocol"]
assert cfg["seeds"] == freeze["seeds"] == [83131, 83161, 83191]
assert len(set(cfg["seeds"])) == 3
assert cfg["prospective_freeze"] is True
assert freeze["heldout_used_for_updates"] is False
assert freeze["heldout_used_for_checkpoint_selection"] is False
assert freeze["unchanged_training_hyperparameters"] is True
print("static three-seed package checks: PASS")
