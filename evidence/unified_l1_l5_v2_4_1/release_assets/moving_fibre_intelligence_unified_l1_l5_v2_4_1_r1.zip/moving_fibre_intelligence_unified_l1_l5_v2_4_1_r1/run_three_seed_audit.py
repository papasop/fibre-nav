#!/usr/bin/env python3
"""Run and aggregate the frozen three-seed unified MFI L1-L5 audit."""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
import time
from pathlib import Path


def stream(cmd, cwd, log_path):
    print("+", " ".join(map(str, cmd)), flush=True)
    with log_path.open("w", encoding="utf-8") as log:
        proc = subprocess.Popen(
            list(map(str, cmd)), cwd=cwd, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, bufsize=1)
        assert proc.stdout is not None
        for line in proc.stdout:
            print(line, end="", flush=True)
            log.write(line)
            log.flush()
        return proc.wait()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config_audit.json")
    ap.add_argument("--output", default="results")
    args = ap.parse_args()
    started = time.time()
    root = Path(__file__).resolve().parent
    config_path = Path(args.config).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)

    records = []
    for index, seed in enumerate(cfg["seeds"], start=1):
        seed_dir = out / f"seed_{seed}"
        seed_dir.mkdir()
        seed_cfg = dict(cfg["single_seed_configuration"])
        seed_cfg.update({
            "protocol": cfg["protocol"] + f"_SEED_{seed}",
            "scientific_status": "FROZEN_COMPONENT_OF_THREE_SEED_UNIFIED_CONFIRMATION",
            "prospective_freeze": True,
            "seed": seed,
        })
        seed_cfg_path = seed_dir / "config.json"
        seed_cfg_path.write_text(json.dumps(seed_cfg, indent=2) + "\n", encoding="utf-8")
        print(f"[seed {seed}] unified audit {index}/{len(cfg['seeds'])}", flush=True)
        code = stream([
            sys.executable, "-u", root / "run_unified_audit.py",
            "--config", seed_cfg_path, "--output", seed_dir,
        ], root, seed_dir / "console.log")
        result_path = seed_dir / "unified_l1_l5_audit.json"
        if code != 0 or not result_path.is_file():
            raise RuntimeError(f"Seed {seed} failed with exit code {code}")
        records.append(json.loads(result_path.read_text(encoding="utf-8")))

    seed_pass = {str(r["seed"]): bool(r["all_gates_pass"]) for r in records}
    stages = [stage for r in records for stage in r["program"]]
    minimum_heldout_margin = min(s["minimum_heldout_margin"] for s in stages)
    maximum_response_drift = max(s["response_drift"] for s in stages)
    maximum_anchor_kl = max(s["anchor_kl"] for s in stages)
    maximum_transport_residual = max(
        max(r["transport"]["target_response_residual"],
            r["transport"]["return_response_residual"])
        for r in records)
    layer_pass_counts = {
        layer: sum(all(r["layer_gates"][layer].values()) for r in records)
        for layer in ("L1", "L2", "L3", "L4", "L5")
    }
    aggregate = {
        "protocol": cfg["protocol"],
        "scientific_status": cfg["scientific_status"],
        "claim_boundary": cfg["claim_boundary"],
        "seeds": cfg["seeds"],
        "seeds_complete": len(records),
        "seed_pass": seed_pass,
        "seeds_all_gates_pass": sum(seed_pass.values()),
        "layer_pass_counts": layer_pass_counts,
        "worst_case_metrics": {
            "minimum_heldout_margin": minimum_heldout_margin,
            "maximum_response_drift": maximum_response_drift,
            "maximum_anchor_kl": maximum_anchor_kl,
            "maximum_transport_or_return_residual": maximum_transport_residual,
        },
        "all_seeds_pass": all(seed_pass.values()),
        "config_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
        "elapsed_seconds": time.time() - started,
        "python": platform.python_version(),
    }
    (out / "THREE_SEED_SUMMARY.json").write_text(
        json.dumps(aggregate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(aggregate, indent=2), flush=True)
    raise SystemExit(0 if aggregate["all_seeds_pass"] else 1)


if __name__ == "__main__":
    main()
