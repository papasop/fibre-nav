# MFI Unified Prospective Three-Seed L1-L5 Audit — v2.4.1-r1

`r1` is a launcher/package repair only. The scientific protocol, seeds,
hyperparameters, thresholds, and pass rule are unchanged from v2.4.1.

This package independently executes the frozen unified L1-L5 shared-state
protocol on three prospectively declared seeds: `83131`, `83161`, and `83191`.
Training hyperparameters, thresholds, operation order, and held-out expression
family are identical across seeds and unchanged from v2.4.0.

Each seed runs the complete unified sequence:

```text
WRITE -> L3 REASSIGN -> selective OVERWRITE -> SWAP -> MOVE -> RETURN
```

The overall audit passes only if every declared L1, L2, L3, L4, and L5 gate
passes independently on all three seeds. `THREE_SEED_SUMMARY.json` reports
per-seed outcomes, layer pass counts, and worst-case metrics.

## Colab

Run `run_moving_fibre_intelligence_unified_l1_l5_v2_4_1.py`, upload the source
ZIP when prompted, and download the generated results ZIP. On an A100, allow
about 70–100 minutes after dependencies and model files are available; reserve
up to two hours for a cold environment.

## Direct run

```bash
python run_three_seed_audit.py --config config_audit.json --output results
```

## Evidence boundary

A pass is unified three-seed evidence for representative L1-L5 capabilities in
one continuous shared-state protocol per seed. Its L4 stage verifies target and
return response eligibility plus exact and held-out access preservation. It
does not replace the full L4 eight-endpoint, 28-relation geometry audit with
matched-random discrimination. It does not establish cross-model replication,
global transport, capacity scaling, arbitrary program closure, gradient-free
operation, or autonomous instruction parsing.
