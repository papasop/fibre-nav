# MFI joint L1–L5 reassignment margin polish — v2.3.2.1

This package follows the near-pass of v2.3.2 at seed `83001`. It retains the
same expression bridges, raises only the L3 REASSIGN training steps, worst-item
weight and signed-margin target, and introduces no new expressions. The three
held-out prefix families remain excluded from updates and checkpoint selection.

The continuous shared-state sequence is:

```text
WRITE → L3 REASSIGN → selective OVERWRITE → SWAP → MOVE → RETURN
```

Representative gates are reported separately for L1, L2, L3, L4 and L5.
Training checkpoints are selected without held-out-expression results.

## Run

```bash
python run_joint_smoke.py --config config_audit.json --output results
```

On an A100, allow approximately 25–45 minutes; use a 60-minute hard timeout.

## Claim boundary

A pass supports only this statement:

> A post-failure reassignment margin polish reproduced representative capabilities
> from all five MFI levels in one continuous protocol at seed 83001.

It must not be reported as prospective, fresh-seed or independent
confirmation. After a pass, confirmation requires freezing this repair and
running a new seed with a new held-out expression family.

This reduced audit does not replace the complete layer-specific evidence. In
particular, its L4 component tests shared-state MOVE/RETURN access preservation,
not the eight-endpoint, 28-relation geometry and matched-random discrimination
of the full L4 audit. It is not multi-seed or cross-model confirmation,
gradient-free inference-time memory, autonomous instruction execution,
arbitrary program composition or global transport.
