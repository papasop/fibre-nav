# Claim boundary

This protocol was designed after inspecting v2.3.0--v2.3.2 at seed 83001. It
retains the v2.3.2 expression bridge and applies a targeted L3 reassignment
margin polish in one GPT-2 LoRA chart. Held-out expressions remain
evaluation-only.

It is designed to test whether the five representative capabilities can occur
in one continuous protocol after the targeted repair. It is not prospective or
independent confirmation, is not a replacement for the complete L1–L5
layer-specific audits, and does not establish multi-seed confirmation,
cross-model replication, full L4 pair-geometry discrimination, autonomous
instruction execution, gradient-free operations or global transport.
