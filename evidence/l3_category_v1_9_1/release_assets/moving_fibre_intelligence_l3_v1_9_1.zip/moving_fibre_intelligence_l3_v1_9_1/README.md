# Moving Fibre Intelligence L3 v1.9.1 — prospective confirmation

This prospective single-seed confirmation freezes the v1.9.0 mechanism and
thresholds before execution, but uses a fresh seed and a new balanced
whole-concept holdout split. No result is bundled and no parameter may be
changed after observing the confirmation run.

The router now combines ridge classification with cosine prototypes fitted
only on the 16 training concepts. Low-confidence ridge decisions switch to
the training-only prototype prediction. Category geometry is audited in the
predeclared response-kernel direction coordinates, preventing unrelated
high-dimensional writer residuals from dominating the category metric. Every
endpoint remains prospectively backtracked, response-retracted and audited.

Frozen design:

- GPT-2 and LoRA-B parameter fibre
- fresh seed `82101`
- 24 concepts in four categories
- 16 router-training concepts and eight new whole-concept holdouts
- writer steps `600`
- category projection rank `4`
- code rotations `4`
- semantic pull weight `1.0`
- move range `0.75` to `6.0`
- confidence sigmoid center `0.50`, temperature `0.20`
- prototype switch threshold `0.25`
- category metric residual weight `0.0`
- shuffled-category, pair-only and no-graph controls
- unchanged category accuracy, positive-margin and distance-ratio gates

Frozen heldouts are `cairo`, `lima`, `egypt`, `peru`, `africa`,
`south_america`, `mango`, and `pear`—exactly two per category. The experiment
tests whether the v1.9.0 mechanism transfers without adjustment. It does not
run L4.

Expected A100 runtime: approximately 75–100 minutes. Prospective confirmation
pending; not confirmation until the frozen run completes.
