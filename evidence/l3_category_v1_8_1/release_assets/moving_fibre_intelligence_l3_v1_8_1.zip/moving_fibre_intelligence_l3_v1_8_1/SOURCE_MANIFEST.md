# Source manifest — MFI L3 v1.8.1

- Frozen development seed: `82001`
- Passing v1.7.8 slot-factorized writer and KL/response gates retained
- 24 concepts, four categories, 16 metric-fit and eight whole-concept holdouts
- Two-bit codes balanced inside every training category
- Shared semantic router fit only on 16 training concepts
- Four tetrahedral class directions projected into the response kernel
- Prospective backtracking, response retraction and post-move memory audit
- Shuffled-category, pair-only and no-category controls
- L4 not executed
- Full per-endpoint histories retained
- Held-out prompts excluded from training/checkpoint selection
- Scientific status: development, not confirmation

Exact hashes are stored in `PACKAGE_SHA256SUMS.txt` when packaged.
