# Moving Fibre Intelligence L3 v1.8.1 — shared category-conditioned writer

This single-seed mechanism audit freezes the 24 concept design and passing
v1.7.8 memory writer. A shared ridge router is fit on frozen GPT-2 description
features from 16 training concepts only. Its prediction selects one of four
deterministic tetrahedral directions projected into the declared response
kernel. Eight whole concepts remain absent from router fitting.

Every routed endpoint is prospectively backtracked, response-retracted and
re-audited for exact, training-expression and held-out-expression access. The
primary arm is compared with shuffled-category, pair-only and no-category
controls. Held-out category labels never enter router fitting or movement.

Seed `82001`, 520 steps per concept, writer optimization and KL/response gates
remain frozen. L4 is not run.

Expected A100 runtime: approximately 75–105 minutes. Development only.
