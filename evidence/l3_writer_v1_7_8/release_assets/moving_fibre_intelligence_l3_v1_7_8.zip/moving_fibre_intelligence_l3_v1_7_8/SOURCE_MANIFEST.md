# Source manifest — MFI L3 v1.7.8

- Frozen development seed: `81902`
- Frozen v1.7.7 prompt sets, canonical suffix, seed, rotations and KL/response gates
- Robust worst-environment terms factorized independently by slot
- Mixed-code contrast target 1.5, weight 2.0, and 0.5 training-margin gate
- Canonical address suffix and all held-out prompts unchanged
- Four concepts × four cyclic code assignments × 520 steps
- Graph scaffold and L4 not executed
- Full per-endpoint histories retained
- Held-out prompts excluded from training/checkpoint selection
- Scientific status: development, not confirmation

Exact hashes are stored in `PACKAGE_SHA256SUMS.txt` when packaged.
