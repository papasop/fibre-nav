# Moving Fibre Intelligence L3 v1.7.8 — mixed-slot margin repair

This single-seed repair keeps the v1.7.7 prompts, seed, rotations, response
budget, KL gate and held-out evaluation frozen. It retains the slot-factorized
writer, raises the mixed-code ordered contrast target from 1.0 to 1.5 and its
weight from 1.5 to 2.0, and extends L3 writing from 420 to 520 steps. A frozen
0.5 minimum training-margin gate is reported for every mixed code. Held-out
prompts remain excluded from training and checkpoint selection.

Seed `81902`, 520 steps, four cyclic rotations, optimization, KL/response gates,
and evaluation criteria remain frozen. Graph refinement and L4 are not run.

Expected A100 runtime: approximately 45–60 minutes. Development only.
