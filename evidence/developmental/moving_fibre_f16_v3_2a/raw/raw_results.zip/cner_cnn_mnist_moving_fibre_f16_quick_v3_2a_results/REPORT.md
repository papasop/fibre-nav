# Moving-Fibre F16 Pareto-closure preflight v3.2a

```json
{
  "scientific_status": "MOVING_FIBRE_F16_V32A_PARETO_CLOSURE_CANDIDATE_SUPPORTED",
  "seeds": 4,
  "fully_comparable": 4,
  "required_comparable": 3,
  "counts": {
    "natural_action_minimum": 4,
    "natural_retraction_cost_minimum": 0,
    "natural_pareto_nondominated": 4,
    "natural_action_beats_wrong_natural": 4,
    "natural_jointly_dominates_wrong_natural": 0,
    "natural_wins_under_wrong_metric": 0,
    "natural_rowspace_rotation_signal": 4
  },
  "moving_fibre_f16_candidate_gate": true,
  "excluded": [],
  "per_seed": [
    {
      "seed": 71726,
      "action_winner": "natural_gradient",
      "retraction_cost_winner": "wrong_fisher_natural_gradient",
      "wrong_metric_action_winner": "wrong_fisher_natural_gradient",
      "pareto_front": [
        "sign_gradient",
        "natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "natural_action": 0.4737139296365208,
      "natural_retraction_fisher_cost": 0.0013510540040314253,
      "wrong_natural_action": 0.48913637848979546,
      "wrong_natural_retraction_fisher_cost": 0.0003459155052700835,
      "natural_action_minus_wrong": -0.01542244885327465,
      "natural_cost_minus_wrong": 0.0010051384987613417,
      "arms": {
        "adam": {
          "moving_fibre_action": 0.49224059008493437,
          "retraction_fisher_cost": 0.0005420889102479251,
          "moving_fisher_length": 0.5312097151763737,
          "steps": 14
        },
        "normalized_sgd": {
          "moving_fibre_action": 0.492971577443079,
          "retraction_fisher_cost": 0.0003474477561267781,
          "moving_fisher_length": 0.5096096815541387,
          "steps": 13
        },
        "normalized_momentum": {
          "moving_fibre_action": 0.4932035257073334,
          "retraction_fisher_cost": 0.0003469123022815133,
          "moving_fisher_length": 0.5098422048613429,
          "steps": 13
        },
        "sign_gradient": {
          "moving_fibre_action": 0.48372680161576154,
          "retraction_fisher_cost": 0.000683028078565193,
          "moving_fisher_length": 0.5249353609979153,
          "steps": 14
        },
        "natural_gradient": {
          "moving_fibre_action": 0.4737139296365208,
          "retraction_fisher_cost": 0.0013510540040314253,
          "moving_fisher_length": 0.4471235496457666,
          "steps": 12
        },
        "wrong_fisher_natural_gradient": {
          "moving_fibre_action": 0.48913637848979546,
          "retraction_fisher_cost": 0.0003459155052700835,
          "moving_fisher_length": 0.5074449107050896,
          "steps": 13
        }
      }
    },
    {
      "seed": 71727,
      "action_winner": "natural_gradient",
      "retraction_cost_winner": "adam",
      "wrong_metric_action_winner": "wrong_fisher_natural_gradient",
      "pareto_front": [
        "adam",
        "natural_gradient"
      ],
      "natural_action": 0.46828797334054084,
      "natural_retraction_fisher_cost": 0.002444618798337446,
      "wrong_natural_action": 0.7393506324755338,
      "wrong_natural_retraction_fisher_cost": 0.0011022437560848624,
      "natural_action_minus_wrong": -0.27106265913499294,
      "natural_cost_minus_wrong": 0.0013423750422525836,
      "arms": {
        "adam": {
          "moving_fibre_action": 0.6440648164650445,
          "retraction_fisher_cost": 0.0009342458921685,
          "moving_fisher_length": 0.755416713654995,
          "steps": 19
        },
        "normalized_sgd": {
          "moving_fibre_action": 0.7231936811314436,
          "retraction_fisher_cost": 0.0012170147335582616,
          "moving_fisher_length": 0.84403131227009,
          "steps": 22
        },
        "normalized_momentum": {
          "moving_fibre_action": 0.7239814121026397,
          "retraction_fisher_cost": 0.0012147246244248223,
          "moving_fisher_length": 0.8450358423870057,
          "steps": 22
        },
        "sign_gradient": {
          "moving_fibre_action": 0.6596784697273502,
          "retraction_fisher_cost": 0.0010280980987217205,
          "moving_fisher_length": 0.7766144936904311,
          "steps": 20
        },
        "natural_gradient": {
          "moving_fibre_action": 0.46828797334054084,
          "retraction_fisher_cost": 0.002444618798337446,
          "moving_fisher_length": 0.5393323600292206,
          "steps": 14
        },
        "wrong_fisher_natural_gradient": {
          "moving_fibre_action": 0.7393506324755338,
          "retraction_fisher_cost": 0.0011022437560848624,
          "moving_fisher_length": 0.8619857942685485,
          "steps": 22
        }
      }
    },
    {
      "seed": 71728,
      "action_winner": "natural_gradient",
      "retraction_cost_winner": "wrong_fisher_natural_gradient",
      "wrong_metric_action_winner": "wrong_fisher_natural_gradient",
      "pareto_front": [
        "normalized_sgd",
        "natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "natural_action": 0.6297690135010455,
      "natural_retraction_fisher_cost": 0.0020715090368076516,
      "wrong_natural_action": 0.7201692659076873,
      "wrong_natural_retraction_fisher_cost": 0.0004405131492584056,
      "natural_action_minus_wrong": -0.09040025240664173,
      "natural_cost_minus_wrong": 0.001630995887549246,
      "arms": {
        "adam": {
          "moving_fibre_action": 0.7143030754129149,
          "retraction_fisher_cost": 0.0006481025745179385,
          "moving_fisher_length": 0.706213659606874,
          "steps": 18
        },
        "normalized_sgd": {
          "moving_fibre_action": 0.7065950576771725,
          "retraction_fisher_cost": 0.0005028554991461201,
          "moving_fisher_length": 0.7231246517039835,
          "steps": 19
        },
        "normalized_momentum": {
          "moving_fibre_action": 0.7067270431400252,
          "retraction_fisher_cost": 0.0005091262139695534,
          "moving_fisher_length": 0.7235872499877587,
          "steps": 19
        },
        "sign_gradient": {
          "moving_fibre_action": 0.742143134911391,
          "retraction_fisher_cost": 0.0009023226573040427,
          "moving_fisher_length": 0.7329723010770977,
          "steps": 19
        },
        "natural_gradient": {
          "moving_fibre_action": 0.6297690135010455,
          "retraction_fisher_cost": 0.0020715090368076516,
          "moving_fisher_length": 0.6354801300913095,
          "steps": 16
        },
        "wrong_fisher_natural_gradient": {
          "moving_fibre_action": 0.7201692659076873,
          "retraction_fisher_cost": 0.0004405131492584056,
          "moving_fisher_length": 0.7312320307828486,
          "steps": 19
        }
      }
    },
    {
      "seed": 71729,
      "action_winner": "natural_gradient",
      "retraction_cost_winner": "normalized_sgd",
      "wrong_metric_action_winner": "wrong_fisher_natural_gradient",
      "pareto_front": [
        "adam",
        "normalized_sgd",
        "normalized_momentum",
        "natural_gradient"
      ],
      "natural_action": 0.4309632234151318,
      "natural_retraction_fisher_cost": 0.0015047328599019363,
      "wrong_natural_action": 0.5580781958200436,
      "wrong_natural_retraction_fisher_cost": 0.0004820752373925132,
      "natural_action_minus_wrong": -0.12711497240491176,
      "natural_cost_minus_wrong": 0.001022657622509423,
      "arms": {
        "adam": {
          "moving_fibre_action": 0.5101131956727231,
          "retraction_fisher_cost": 0.0005286079148881157,
          "moving_fisher_length": 0.5397388348355889,
          "steps": 14
        },
        "normalized_sgd": {
          "moving_fibre_action": 0.5563541039640371,
          "retraction_fisher_cost": 0.0004548438035835827,
          "moving_fisher_length": 0.5867658816277981,
          "steps": 15
        },
        "normalized_momentum": {
          "moving_fibre_action": 0.5562531361592823,
          "retraction_fisher_cost": 0.0004555709633832467,
          "moving_fisher_length": 0.5866871923208237,
          "steps": 15
        },
        "sign_gradient": {
          "moving_fibre_action": 0.532135746913136,
          "retraction_fisher_cost": 0.0006917690717792755,
          "moving_fisher_length": 0.5600367955212278,
          "steps": 15
        },
        "natural_gradient": {
          "moving_fibre_action": 0.4309632234151318,
          "retraction_fisher_cost": 0.0015047328599019363,
          "moving_fisher_length": 0.4526569484733045,
          "steps": 12
        },
        "wrong_fisher_natural_gradient": {
          "moving_fibre_action": 0.5580781958200436,
          "retraction_fisher_cost": 0.0004820752373925132,
          "moving_fisher_length": 0.589019387960434,
          "steps": 15
        }
      }
    }
  ],
  "claim_boundary": "Four-seed developmental preflight joining v3.1e admissibility and F16 ordering. Six named algorithms are generated causally in a transported eight-dimensional chart projected into the current response kernel at every step, with a common 20% capability endpoint. The two primary axes are moving capacity-normalized Fisher action and response-retraction Fisher cost; no fitted lambda or scalar composite is used. A pass is a Pareto-closure candidate only, not 16-seed confirmation, complete-kernel optimization, continuum geometry, local stationarity, GPT-2 transfer, global variation, or a universal learning law."
}
```
