# Pythia-160M adaptive-metric constrained Onsager R17b

One-seed development diagnostic of an adaptive-metric incremental variational
principle nominated by R17a. SST-2 learning loss and frozen AG News response
coordinates remain strictly separated.

The candidate microstep is the exact constrained minimizer

`min_delta <mhat,delta> + delta^T M delta/(2 eta), subject to DR(theta)delta=0`,

where `M=diag(sqrt(vhat)+eps)`. The exact metric-constrained solution is tested
against current-kernel projected AdamW, current Euclidean Onsager, and
source-frozen metric Onsager under the same batches, step norm and response ball.

This is development only. A positive result nominates the frozen configuration
for untouched-seed confirmation; it is not itself a continuous-action theorem
or a universal optimizer claim.

## Colab

Run `COLAB_LAUNCHER_R17B.py`, upload `pythia160m_metric_onsager_r17b.zip`, and wait for
the automatically downloaded result ZIP. An A100 is required for the full run.
Use `--quick` only for a nonclaim smoke test.
