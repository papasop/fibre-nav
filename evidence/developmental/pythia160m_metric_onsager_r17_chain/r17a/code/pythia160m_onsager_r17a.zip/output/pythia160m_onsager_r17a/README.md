# Pythia-160M constrained Onsager R17a

One-seed development diagnostic of a preregistered incremental variational
principle. The SST-2 learning loss and frozen AG News response coordinates are
strictly separated.

The candidate microstep is the exact constrained minimizer

`min_delta <grad L,delta> + ||delta||^2/(2 eta), subject to DR(theta)delta=0`,

so `delta* = -eta P_kerDR(theta) grad L`. The experiment checks KKT agreement,
finite nonlinear response-budget compliance, and final-loss ordering against
source-frozen, current-kernel projected AdamW, and a same-dimensional frozen
random-kernel control.

This is development only. A positive result nominates the frozen configuration
for untouched-seed confirmation; it is not itself a continuous-action theorem
or a universal optimizer claim.

## Colab

Run `COLAB_LAUNCHER_R17A.py`, upload `pythia160m_onsager_r17a.zip`, and wait for
the automatically downloaded result ZIP. An A100 is required for the full run.
Use `--quick` only for a nonclaim smoke test.
