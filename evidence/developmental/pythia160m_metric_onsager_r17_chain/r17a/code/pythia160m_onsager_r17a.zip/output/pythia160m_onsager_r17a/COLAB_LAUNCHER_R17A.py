#!/usr/bin/env python3
"""Colab launcher: upload one R17a ZIP, run, and download results."""
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


def main():
    from google.colab import files
    uploaded = files.upload()
    bundles = [Path(name) for name in uploaded
               if name.lower().endswith(".zip") and "r17" in name.lower()]
    if len(bundles) != 1:
        raise SystemExit("Upload exactly one pythia160m_onsager_r17a.zip")
    root = Path("/content/pythia_r17a_run")
    out = Path("/content/pythia_r17a_results")
    for path in (root, out):
        if path.exists(): shutil.rmtree(path)
        path.mkdir(parents=True)
    with zipfile.ZipFile(bundles[0]) as archive:
        bad = archive.testzip()
        if bad: raise SystemExit(f"Corrupt bundle member: {bad}")
        archive.extractall(root)
    scripts = list(root.rglob("pythia160m_onsager_r17a.py"))
    requirements = list(root.rglob("requirements.txt"))
    if len(scripts) != 1 or len(requirements) != 1:
        raise SystemExit("Invalid R17a bundle layout")
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r",
                    str(requirements[0])], check=True)
    cmd = [sys.executable, str(scripts[0]), "--device", "cuda", "--outdir", str(out)]
    print("Running:", " ".join(cmd), flush=True)
    code = subprocess.run(cmd).returncode
    summary = out / "run_summary.json"
    if summary.exists(): print(summary.read_text())
    else: print(f"No run_summary.json; child exit code={code}", flush=True)
    archive = shutil.make_archive(str(out), "zip", out)
    files.download(archive)
    if code not in (0, 2): raise SystemExit(code)


if __name__ == "__main__":
    main()
