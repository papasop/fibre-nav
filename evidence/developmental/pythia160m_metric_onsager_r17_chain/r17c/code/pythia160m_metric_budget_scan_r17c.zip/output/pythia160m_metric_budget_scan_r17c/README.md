# R17c metric-Onsager response-budget calibration

Same-seed mechanism diagnostic following R17b. It intentionally reuses seed
54217 and freezes all data, batches, model, chart, Adam statistics, response
map, response ball, and controls. Only the current metric-Onsager step multiplier
is scanned: `1.00, 1.15, 1.30, 1.45`.

Eligibility is frozen prospectively: response-budget utilization in `[0.80,1.00]`
and zero-step fraction at most `0.05`. Among eligible multipliers, select the
lowest final validation loss, breaking ties toward the smaller multiplier.

This diagnostic can nominate one multiplier for untouched-seed R17d. It cannot
confirm an optimizer ordering itself.
