#!/usr/bin/env python3
"""R16b: fail-closed no-go audit for the A1 response-occupancy action.

This CPU postprocessor consumes the frozen R16a-r6 result archive. It does not
run or refit Pythia. Central first variations are extrapolated linearly in
epsilon^2 to epsilon=0, as appropriate for a centered difference. The result
can reject stationarity of A1 and locally non-flat scalar reparameterizations
phi(A1); it cannot reject joint response-learning actions.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import time
import zipfile
from pathlib import Path

PROTOCOL = "PYTHIA160M_RESPONSE_OCCUPANCY_STATIONARITY_NOGO_R16B_DIAGNOSTIC"
EXPECTED_SOURCE = "PYTHIA160M_SST2_AGNEWS_FIXED_ENDPOINT_VARIATION_R16A_R6_DIAGNOSTIC"
EXPECTED_FIELDS = (51818, 51820, 51824)
EXPECTED_EPS = (0.001, 0.003, 0.006)
EXPECTED_ORDERS = ("8", "16")
NONZERO_FLOOR = 1e-4
ORDER_RELATIVE_TOLERANCE = .01


def load_summary(path: Path):
    if path.suffix.lower() == ".json":
        return json.loads(path.read_text())
    with zipfile.ZipFile(path) as archive:
        names = [name for name in archive.namelist() if name.endswith("run_summary.json")]
        if len(names) != 1:
            raise RuntimeError(f"expected one run_summary.json, found {len(names)}")
        return json.loads(archive.read(names[0]))


def intercept_at_zero(xs, ys):
    """Least-squares intercept for y = intercept + slope*x."""
    xm, ym = statistics.mean(xs), statistics.mean(ys)
    denominator = sum((x - xm) ** 2 for x in xs)
    slope = sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / denominator
    intercept = ym - slope * xm
    residuals = [y - (intercept + slope * x) for x, y in zip(xs, ys)]
    return intercept, slope, max(abs(value) for value in residuals)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="R16a-r6 result ZIP or run_summary.json")
    parser.add_argument("--outdir", default="pythia_r16b_results")
    args = parser.parse_args()
    started = time.time()
    source = load_summary(Path(args.input))
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    fields = source.get("fixed_endpoint_variations", [])
    analyses = []
    for field in fields:
        seed = int(field["field_seed"])
        rows = sorted(field["rows"], key=lambda row: float(row["epsilon"]))
        eps = [float(row["epsilon"]) for row in rows]
        by_order = {}
        for order in EXPECTED_ORDERS:
            first = [float(row["by_order"][order]["central_first_variation"])
                     for row in rows]
            second = [float(row["by_order"][order]["central_second_variation"])
                      for row in rows]
            intercept, slope, residual = intercept_at_zero(
                [value * value for value in eps], first)
            by_order[order] = {
                "central_first_variations": first,
                "central_second_variations": second,
                "epsilon_zero_first_variation": intercept,
                "epsilon_squared_slope": slope,
                "maximum_first_variation_fit_residual": residual,
                "nonzero_at_frozen_floor": abs(intercept) >= NONZERO_FLOOR,
            }
        i8, i16 = (by_order[order]["epsilon_zero_first_variation"]
                    for order in EXPECTED_ORDERS)
        order_relative_error = abs(i8 - i16) / max(abs(i8), abs(i16), 1e-30)
        smallest = rows[0]
        descent = {}
        for order in EXPECTED_ORDERS:
            record = smallest["by_order"][order]
            base = float(record["base_action"])
            plus = float(record["plus_action"])
            minus = float(record["minus_action"])
            descent[order] = {
                "sign": "+" if plus < minus else "-",
                "best_action": min(plus, minus),
                "base_action": base,
                "strict_decrease": min(plus, minus) < base,
            }
        analyses.append({
            "field_seed": seed, "epsilons": eps, "by_order": by_order,
            "epsilon_zero_order_relative_error": order_relative_error,
            "epsilon_zero_sign_agreement": i8 * i16 > 0,
            "smallest_epsilon_descent": descent,
            "has_negative_second_variation": any(
                value < -1e-6 for order in by_order.values()
                for value in order["central_second_variations"]),
        })
    source_gates = source.get("numerical_gates", {})
    gates = {
        "source_protocol_exact": source.get("protocol") == EXPECTED_SOURCE,
        "three_frozen_fields_exact": tuple(a["field_seed"] for a in analyses) == EXPECTED_FIELDS,
        "three_frozen_epsilons_exact": all(tuple(a["epsilons"]) == EXPECTED_EPS for a in analyses),
        "source_endpoints_exact": source_gates.get("fixed_endpoints_exact") is True,
        "source_response_ball_respected": source_gates.get(
            "all_perturbed_paths_respect_response_ball") is True,
        "source_8_16_actions_stable": source_gates.get(
            "all_perturbed_actions_stable_between_orders_8_and_16") is True,
        "all_epsilon_zero_first_variations_nonzero": bool(analyses) and all(
            order["nonzero_at_frozen_floor"] for analysis in analyses
            for order in analysis["by_order"].values()),
        "all_epsilon_zero_signs_agree_between_orders": bool(analyses) and all(
            analysis["epsilon_zero_sign_agreement"] for analysis in analyses),
        "all_epsilon_zero_order_relative_errors_at_most_1pct": bool(analyses) and all(
            analysis["epsilon_zero_order_relative_error"] <= ORDER_RELATIVE_TOLERANCE
            for analysis in analyses),
        "every_field_has_feasible_descent_sign_at_smallest_epsilon": bool(analyses) and all(
            item["strict_decrease"] for analysis in analyses
            for item in analysis["smallest_epsilon_descent"].values()),
        "at_least_one_field_has_negative_second_variation": any(
            analysis["has_negative_second_variation"] for analysis in analyses),
    }
    rejected = all(gates.values())
    summary = {
        "protocol": PROTOCOL,
        "mode": "same_result_response_only_stationarity_nogo",
        "source_protocol": source.get("protocol"),
        "source_seed": source.get("seed"),
        "frozen_thresholds": {
            "absolute_epsilon_zero_first_variation_floor": NONZERO_FLOOR,
            "order_8_16_relative_tolerance": ORDER_RELATIVE_TOLERANCE,
            "negative_second_variation_tolerance": -1e-6,
        },
        "field_analyses": analyses,
        "gates": gates,
        "scientific_status": ("R16B_A1_RESPONSE_OCCUPANCY_STATIONARITY_REJECTED"
                              if rejected else "R16B_RESPONSE_ONLY_NOGO_INCONCLUSIVE_FAIL_CLOSED"),
        "logical_consequence": (
            "If delta A1 is nonzero, delta phi(A1)=phi'(A1) delta A1 is also nonzero for every differentiable scalar reparameterization with phi'(A1) != 0. This does not cover locally flat phi or actions with additional path-dependent terms."),
        "next_admissible_direction": (
            "Derive and preregister a joint response-learning or energy-dissipation action before any new Pythia variation run."),
        "wall_seconds": time.time() - started,
        "claim_boundary": (
            "CPU postprocessing of one same-seed R16a-r6 diagnostic. It rejects stationarity of A1 along three frozen feasible fields, and consequently locally non-flat differentiable scalar reparameterizations phi(A1). It does not reject all response-only functionals, joint response-learning actions, geometric-flow ODE existence, Principle R, K=1, or any universal variational law."),
    }
    (out / "run_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
