# R16b single-upload CPU audit

This bundle contains both the R16b postprocessor and the frozen R16a-r6
`run_summary.json` used as its input. It does not download or execute Pythia.

In Colab, run `run_pythia_r16b_all_in_one_colab.py` and upload only
`pythia160m_response_only_nogo_r16b_all_in_one.zip` when prompted.

The audit is diagnostic and fail-closed. It can reject stationarity of the A1
response-occupancy functional along the three preregistered feasible fields;
it cannot reject all response-only actions or joint response-learning actions.
