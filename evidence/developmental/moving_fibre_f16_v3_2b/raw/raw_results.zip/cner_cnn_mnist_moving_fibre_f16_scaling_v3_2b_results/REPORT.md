# Moving-Fibre F16 multi-radius scaling audit v3.2b

```json
{
  "scientific_status": "MOVING_FIBRE_F16_V32B_DISCRETIZATION_BRANCH_SUPPORTED",
  "seeds": 4,
  "fully_comparable": 4,
  "required_comparable": 3,
  "counts": {
    "natural_action_minimum_at_all_radii": 3,
    "natural_action_minimum_at_smallest_radius": 3,
    "natural_action_beats_wrong_at_all_radii": 3,
    "all_algorithms_positive_retraction_scaling": 3,
    "all_algorithms_high_quality_scaling_fit": 4,
    "all_algorithms_action_converged": 4,
    "natural_wins_under_wrong_metric_at_any_radius": 0,
    "natural_rowspace_rotation_signal": 4
  },
  "moving_fibre_f16_scaling_gate": true,
  "excluded": [],
  "per_seed": [
    {
      "seed": 72726,
      "step_radii": [
        0.08,
        0.04,
        0.02,
        0.01
      ],
      "action_winners": [
        "natural_gradient",
        "natural_gradient",
        "natural_gradient",
        "natural_gradient"
      ],
      "retraction_cost_winners": [
        "normalized_momentum",
        "normalized_sgd",
        "adam",
        "wrong_fisher_natural_gradient"
      ],
      "wrong_metric_action_winners": [
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "fits": {
        "adam": {
          "retraction_exponent": 0.8003229067664331,
          "retraction_r2": 0.9867876596467549
        },
        "normalized_sgd": {
          "retraction_exponent": 0.47976934903280744,
          "retraction_r2": 0.9862608957418043
        },
        "normalized_momentum": {
          "retraction_exponent": 0.48680879944594385,
          "retraction_r2": 0.9883749529280041
        },
        "sign_gradient": {
          "retraction_exponent": 0.764179611525358,
          "retraction_r2": 0.9942448285457369
        },
        "natural_gradient": {
          "retraction_exponent": 0.7714333259649604,
          "retraction_r2": 0.998421873516939
        },
        "wrong_fisher_natural_gradient": {
          "retraction_exponent": 0.6292965153759786,
          "retraction_r2": 0.9992952590670808
        }
      },
      "small_step_action_relative_changes": {
        "adam": 0.007889185203748221,
        "normalized_sgd": 0.0001237770412993337,
        "normalized_momentum": 0.00017746397004334366,
        "sign_gradient": 0.001671922282677269,
        "natural_gradient": 0.0010313945222488927,
        "wrong_fisher_natural_gradient": 5.502269302047566e-05
      },
      "natural_retraction_cost_over_minimum": [
        1.922006309916847,
        1.7913196858969873,
        1.3560038165691806,
        1.0961385115101192
      ],
      "natural_actions": [
        0.5407536265884965,
        0.5390225539785144,
        0.5372408459507235,
        0.5377955253096178
      ],
      "natural_retraction_costs": [
        0.0007777474898718327,
        0.00047047919718075593,
        0.00028111037876178864,
        0.0001553499903313234
      ],
      "wrong_natural_actions": [
        0.5574241739872569,
        0.5570011933946843,
        0.5571152950683211,
        0.5571459507389362
      ],
      "all_algorithms": {
        "adam": {
          "actions": [
            0.6041562777720121,
            0.5971164111221358,
            0.5851079847061298,
            0.5805280910796242
          ],
          "retraction_costs": [
            0.0007290259187450004,
            0.00041250417064657934,
            0.0002073079554252471,
            0.0001443033533763564
          ],
          "steps": [
            9,
            17,
            32,
            64
          ]
        },
        "normalized_sgd": {
          "actions": [
            0.557934174698024,
            0.5569374134536643,
            0.5569475591835674,
            0.5568786303943344
          ],
          "retraction_costs": [
            0.0004063619803884845,
            0.0002626439048734998,
            0.00021035933274779646,
            0.00014442144921872677
          ],
          "steps": [
            8,
            16,
            31,
            61
          ]
        },
        "normalized_momentum": {
          "actions": [
            0.5579569054468526,
            0.5570762821754955,
            0.5569747130992864,
            0.5568758876934349
          ],
          "retraction_costs": [
            0.00040465397322523927,
            0.0002661392392758379,
            0.00021181953710466562,
            0.00014179185097517666
          ],
          "steps": [
            8,
            16,
            31,
            61
          ]
        },
        "sign_gradient": {
          "actions": [
            0.6503400892352929,
            0.638443866940824,
            0.6399772561158877,
            0.638909049838858
          ],
          "retraction_costs": [
            0.0008857472112963126,
            0.0005041435091388002,
            0.00027845532535803103,
            0.00018468830428665457
          ],
          "steps": [
            9,
            18,
            35,
            70
          ]
        },
        "natural_gradient": {
          "actions": [
            0.5407536265884965,
            0.5390225539785144,
            0.5372408459507235,
            0.5377955253096178
          ],
          "retraction_costs": [
            0.0007777474898718327,
            0.00047047919718075593,
            0.00028111037876178864,
            0.0001553499903313234
          ],
          "steps": [
            8,
            15,
            30,
            59
          ]
        },
        "wrong_fisher_natural_gradient": {
          "actions": [
            0.5574241739872569,
            0.5570011933946843,
            0.5571152950683211,
            0.5571459507389362
          ],
          "retraction_costs": [
            0.0005243178246803528,
            0.0003481174813290769,
            0.00022480245203968183,
            0.00014172478085575343
          ],
          "steps": [
            8,
            16,
            31,
            61
          ]
        }
      }
    },
    {
      "seed": 72727,
      "step_radii": [
        0.08,
        0.04,
        0.02,
        0.01
      ],
      "action_winners": [
        "adam",
        "adam",
        "adam",
        "adam"
      ],
      "retraction_cost_winners": [
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "adam",
        "wrong_fisher_natural_gradient"
      ],
      "wrong_metric_action_winners": [
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "fits": {
        "adam": {
          "retraction_exponent": 0.7182565819648293,
          "retraction_r2": 0.9145358833661535
        },
        "normalized_sgd": {
          "retraction_exponent": 0.6739549218156029,
          "retraction_r2": 0.9975816004656133
        },
        "normalized_momentum": {
          "retraction_exponent": 0.6875061490573894,
          "retraction_r2": 0.9981625803923152
        },
        "sign_gradient": {
          "retraction_exponent": 0.8107888018263238,
          "retraction_r2": 0.9957541989569105
        },
        "natural_gradient": {
          "retraction_exponent": 0.6496912224166584,
          "retraction_r2": 0.9974534224428738
        },
        "wrong_fisher_natural_gradient": {
          "retraction_exponent": 0.6703832117792387,
          "retraction_r2": 0.9987554706332098
        }
      },
      "small_step_action_relative_changes": {
        "adam": 0.0006680220183111346,
        "normalized_sgd": 0.0005363070498079592,
        "normalized_momentum": 0.00041709513635154066,
        "sign_gradient": 0.001581226664049649,
        "natural_gradient": 0.01252847078450464,
        "wrong_fisher_natural_gradient": 0.0006667731829791559
      },
      "natural_retraction_cost_over_minimum": [
        3.046990567295178,
        3.104172513584079,
        3.907473009407028,
        3.275958143636001
      ],
      "natural_actions": [
        1.3241827701973412,
        1.28550653424604,
        1.2948341690678549,
        1.2788126027356252
      ],
      "natural_retraction_costs": [
        0.005276136727840376,
        0.00341369723366197,
        0.002050043078688168,
        0.0013938463204124225
      ],
      "wrong_natural_actions": [
        0.8482257636605084,
        0.8481323948958756,
        0.848743467011349,
        0.8481779247167529
      ],
      "all_algorithms": {
        "adam": {
          "actions": [
            0.787552093669084,
            0.790334793875446,
            0.7888804597665608,
            0.7894078015594291
          ],
          "retraction_costs": [
            0.0017937451407351952,
            0.001342378764150867,
            0.000524646766273958,
            0.00046670326875510656
          ],
          "steps": [
            11,
            21,
            41,
            82
          ]
        },
        "normalized_sgd": {
          "actions": [
            0.8240460221161438,
            0.8236585121753881,
            0.8237671581651139,
            0.8233256028400234
          ],
          "retraction_costs": [
            0.0018448982706763155,
            0.0012318290982650535,
            0.0007556325827662267,
            0.0004575622574032464
          ],
          "steps": [
            11,
            21,
            42,
            83
          ]
        },
        "normalized_momentum": {
          "actions": [
            0.8233434769769101,
            0.8238423477805402,
            0.8238715328574943,
            0.8235280433159781
          ],
          "retraction_costs": [
            0.0018560918249237157,
            0.0012247728690934915,
            0.0007345913767148206,
            0.000449506653908839
          ],
          "steps": [
            11,
            21,
            42,
            83
          ]
        },
        "sign_gradient": {
          "actions": [
            0.8645135942297539,
            0.8606259599094374,
            0.8556956468813165,
            0.8543447342072975
          ],
          "retraction_costs": [
            0.0024717711434179253,
            0.0015048366665031364,
            0.0007687717381266937,
            0.0004749702532870234
          ],
          "steps": [
            12,
            23,
            45,
            89
          ]
        },
        "natural_gradient": {
          "actions": [
            1.3241827701973412,
            1.28550653424604,
            1.2948341690678549,
            1.2788126027356252
          ],
          "retraction_costs": [
            0.005276136727840376,
            0.00341369723366197,
            0.002050043078688168,
            0.0013938463204124225
          ],
          "steps": [
            15,
            28,
            56,
            110
          ]
        },
        "wrong_fisher_natural_gradient": {
          "actions": [
            0.8482257636605084,
            0.8481323948958756,
            0.848743467011349,
            0.8481779247167529
          ],
          "retraction_costs": [
            0.0017315894523835095,
            0.0010997124736861076,
            0.0007110984743183132,
            0.0004254774509619913
          ],
          "steps": [
            11,
            22,
            43,
            85
          ]
        }
      }
    },
    {
      "seed": 72728,
      "step_radii": [
        0.08,
        0.04,
        0.02,
        0.01
      ],
      "action_winners": [
        "natural_gradient",
        "natural_gradient",
        "natural_gradient",
        "natural_gradient"
      ],
      "retraction_cost_winners": [
        "normalized_momentum",
        "normalized_momentum",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "wrong_metric_action_winners": [
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "fits": {
        "adam": {
          "retraction_exponent": 0.7101287079631138,
          "retraction_r2": 0.9933496064403877
        },
        "normalized_sgd": {
          "retraction_exponent": 0.6499626969601643,
          "retraction_r2": 0.9884682192970087
        },
        "normalized_momentum": {
          "retraction_exponent": 0.6592095411298269,
          "retraction_r2": 0.9861626202343929
        },
        "sign_gradient": {
          "retraction_exponent": 0.5626862226485209,
          "retraction_r2": 0.9867931076271463
        },
        "natural_gradient": {
          "retraction_exponent": 0.6461698321597442,
          "retraction_r2": 0.9722574584490461
        },
        "wrong_fisher_natural_gradient": {
          "retraction_exponent": 0.7778983782034373,
          "retraction_r2": 0.9912942347789481
        }
      },
      "small_step_action_relative_changes": {
        "adam": 0.004305608271478759,
        "normalized_sgd": 4.7654482545325734e-05,
        "normalized_momentum": 0.00023629232767654663,
        "sign_gradient": 6.760165335894646e-05,
        "natural_gradient": 0.00010758420596517159,
        "wrong_fisher_natural_gradient": 0.00012830956776328195
      },
      "natural_retraction_cost_over_minimum": [
        3.1125852852793945,
        3.113525923386141,
        4.010313457611512,
        3.354090560415571
      ],
      "natural_actions": [
        0.3906824769470141,
        0.39350222775679305,
        0.39609840084948794,
        0.39605579150164133
      ],
      "natural_retraction_costs": [
        0.0035447409751275414,
        0.00260516861849226,
        0.0017324386152752285,
        0.0009125475297199486
      ],
      "wrong_natural_actions": [
        0.4968038889859486,
        0.49551363305870855,
        0.49535118435730185,
        0.4954147508098418
      ],
      "all_algorithms": {
        "adam": {
          "actions": [
            0.4700780154703216,
            0.4706776028583067,
            0.4671011502659151,
            0.46509861781001893
          ],
          "retraction_costs": [
            0.0014595656830267566,
            0.000890938868022274,
            0.0005964726766509553,
            0.000323401940449304
          ],
          "steps": [
            8,
            15,
            30,
            58
          ]
        },
        "normalized_sgd": {
          "actions": [
            0.4875783705809342,
            0.4866696970367482,
            0.48616085320867963,
            0.48618402205667255
          ],
          "retraction_costs": [
            0.0011418679505664265,
            0.0008415993748005785,
            0.000491536613018456,
            0.00030427866436533716
          ],
          "steps": [
            8,
            16,
            31,
            61
          ]
        },
        "normalized_momentum": {
          "actions": [
            0.4879225335873928,
            0.48677663812857014,
            0.48605777880499157,
            0.48617265767392603
          ],
          "retraction_costs": [
            0.0011388413971793725,
            0.000836726169171891,
            0.0005037835581089288,
            0.0002940606290953059
          ],
          "steps": [
            8,
            16,
            31,
            61
          ]
        },
        "sign_gradient": {
          "actions": [
            0.4889998578247477,
            0.48628829783643523,
            0.481657704053601,
            0.48162514539747286
          ],
          "retraction_costs": [
            0.001630165169666832,
            0.0011170597725365125,
            0.0008295603200951483,
            0.0004905571986189318
          ],
          "steps": [
            8,
            16,
            31,
            61
          ]
        },
        "natural_gradient": {
          "actions": [
            0.3906824769470141,
            0.39350222775679305,
            0.39609840084948794,
            0.39605579150164133
          ],
          "retraction_costs": [
            0.0035447409751275414,
            0.00260516861849226,
            0.0017324386152752285,
            0.0009125475297199486
          ],
          "steps": [
            7,
            13,
            26,
            50
          ]
        },
        "wrong_fisher_natural_gradient": {
          "actions": [
            0.4968038889859486,
            0.49551363305870855,
            0.49535118435730185,
            0.4954147508098418
          ],
          "retraction_costs": [
            0.0013052008460565727,
            0.0008594034212769272,
            0.00043199581119702433,
            0.00027207003307832097
          ],
          "steps": [
            8,
            16,
            31,
            62
          ]
        }
      }
    },
    {
      "seed": 72729,
      "step_radii": [
        0.08,
        0.04,
        0.02,
        0.01
      ],
      "action_winners": [
        "natural_gradient",
        "natural_gradient",
        "natural_gradient",
        "natural_gradient"
      ],
      "retraction_cost_winners": [
        "wrong_fisher_natural_gradient",
        "natural_gradient",
        "natural_gradient",
        "natural_gradient"
      ],
      "wrong_metric_action_winners": [
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient",
        "wrong_fisher_natural_gradient"
      ],
      "fits": {
        "adam": {
          "retraction_exponent": 1.0334084999439734,
          "retraction_r2": 0.986891312911121
        },
        "normalized_sgd": {
          "retraction_exponent": 0.6826929880935637,
          "retraction_r2": 0.9889134090168197
        },
        "normalized_momentum": {
          "retraction_exponent": 0.6842462209877147,
          "retraction_r2": 0.9880629216294058
        },
        "sign_gradient": {
          "retraction_exponent": 1.1206497309681642,
          "retraction_r2": 0.9622272558365083
        },
        "natural_gradient": {
          "retraction_exponent": 0.6379365609420492,
          "retraction_r2": 0.9895354694413875
        },
        "wrong_fisher_natural_gradient": {
          "retraction_exponent": 0.5428942423727012,
          "retraction_r2": 0.9598884524542692
        }
      },
      "small_step_action_relative_changes": {
        "adam": 0.00831347105674948,
        "normalized_sgd": 0.0005381668827446508,
        "normalized_momentum": 0.0005563657873834546,
        "sign_gradient": 0.006145526776889302,
        "natural_gradient": 0.0013438459051430519,
        "wrong_fisher_natural_gradient": 9.317334917613303e-05
      },
      "natural_retraction_cost_over_minimum": [
        1.2200072245716937,
        1.0,
        1.0,
        1.0
      ],
      "natural_actions": [
        0.38713072365623946,
        0.38821388493028297,
        0.38869514398725147,
        0.3892181932624744
      ],
      "natural_retraction_costs": [
        0.0008151990464290716,
        0.00046051909777010164,
        0.00031193677420574873,
        0.00021258398891773247
      ],
      "wrong_natural_actions": [
        0.47745972284317856,
        0.47670413815829793,
        0.47691262120721784,
        0.47695706089399453
      ],
      "all_algorithms": {
        "adam": {
          "actions": [
            0.520679773242104,
            0.5178484993359826,
            0.5225916135031126,
            0.5269725848348374
          ],
          "retraction_costs": [
            0.002608519905159653,
            0.0010756000417336015,
            0.0005143344404485214,
            0.00030636515534440966
          ],
          "steps": [
            7,
            14,
            28,
            55
          ]
        },
        "normalized_sgd": {
          "actions": [
            0.4777900315731885,
            0.47807348133958716,
            0.47839442681409894,
            0.47813710925648584
          ],
          "retraction_costs": [
            0.0011103931656390132,
            0.0008039571658036092,
            0.00045213540011406373,
            0.0002778186237292384
          ],
          "steps": [
            7,
            13,
            26,
            52
          ]
        },
        "normalized_momentum": {
          "actions": [
            0.47766909028317206,
            0.47797211641477816,
            0.4783311651372151,
            0.47806518602357245
          ],
          "retraction_costs": [
            0.001113253519469395,
            0.0008100698836963103,
            0.0004531783320052856,
            0.0002780245012359293
          ],
          "steps": [
            7,
            13,
            26,
            52
          ]
        },
        "sign_gradient": {
          "actions": [
            0.5509044533642193,
            0.5527211007291699,
            0.5675513438780614,
            0.5640847459672846
          ],
          "retraction_costs": [
            0.0032627439486662855,
            0.0017068668821789046,
            0.0005176339283837585,
            0.0003645955412150687
          ],
          "steps": [
            8,
            15,
            30,
            59
          ]
        },
        "natural_gradient": {
          "actions": [
            0.38713072365623946,
            0.38821388493028297,
            0.38869514398725147,
            0.3892181932624744
          ],
          "retraction_costs": [
            0.0008151990464290716,
            0.00046051909777010164,
            0.00031193677420574873,
            0.00021258398891773247
          ],
          "steps": [
            6,
            12,
            23,
            46
          ]
        },
        "wrong_fisher_natural_gradient": {
          "actions": [
            0.47745972284317856,
            0.47670413815829793,
            0.47691262120721784,
            0.47695706089399453
          ],
          "retraction_costs": [
            0.000668191982809989,
            0.00056468607036572,
            0.0003635094205499167,
            0.00022075314043331704
          ],
          "steps": [
            7,
            13,
            26,
            51
          ]
        }
      }
    }
  ],
  "claim_boundary": "Four-seed, four-radius developmental audit testing whether the higher finite-step retraction cost of moving-fibre natural gradient vanishes as a discretization effect while its restricted action ordering converges. Six algorithms are generated causally in a transported eight-dimensional chart projected into the current response kernel at every step, with a common 20% capability endpoint. No fitted lambda or scalar composite is used. A pass supports only the discretization branch and authorizes a separately frozen new-seed confirmation; it is not 16-seed confirmation, complete-kernel optimization, continuum geometry, local stationarity, GPT-2 transfer, global variation, or a universal learning law."
}
```
