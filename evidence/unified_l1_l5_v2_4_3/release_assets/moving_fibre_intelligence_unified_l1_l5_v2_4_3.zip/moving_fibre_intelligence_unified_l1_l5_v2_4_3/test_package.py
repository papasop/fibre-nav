#!/usr/bin/env python3
"""Static checks that do not load GPT-2."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
cfg = json.loads((ROOT / "config_audit.json").read_text(encoding="utf-8"))
freeze = json.loads((ROOT / "PROTOCOL_FREEZE.json").read_text(encoding="utf-8"))
assert cfg["protocol"] == freeze["protocol"]
assert cfg["seeds"] == freeze["seeds"] == [83221, 83251, 83281]
assert len(set(cfg["seeds"])) == 3
assert cfg["prospective_freeze"] is True
assert freeze["heldout_used_for_updates"] is False
assert freeze["heldout_used_for_checkpoint_selection"] is False
assert freeze["unchanged_numeric_hyperparameters"] is True
assert freeze["prior_heldout_strings_used_as_training_data"] is False
assert cfg["single_seed_configuration"]["address_constraint_multiplier"] == 4.0
print("static three-seed package checks: PASS")
