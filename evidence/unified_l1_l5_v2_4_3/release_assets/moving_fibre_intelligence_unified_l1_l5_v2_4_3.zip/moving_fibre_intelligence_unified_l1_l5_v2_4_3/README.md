# MFI Unified L1-L5 Expression-Coverage Three-Seed Audit — v2.4.3

v2.4.1 reproduced exact address operations on 3/3 seeds but failed its strict
all-expression gate on 0/3. This package makes one mechanism-level repair:
eight additional generic expression views are added to the training side.
No failed v2.4.1 held-out string is reused for training. The address-constraint
multiplier is now explicitly frozen in `config_audit.json`, and
`SHA256SUMS.txt` authenticates every other file in the source package.

The expanded-coverage protocol is frozen before evaluation on new seeds `83221`,
`83251`, and `83281` and on a new held-out expression family. Numeric
hyperparameters, budgets, thresholds, and the shared-state program are
unchanged.

Each seed runs the complete unified sequence:

```text
WRITE -> L3 REASSIGN -> selective OVERWRITE -> SWAP -> MOVE -> RETURN
```

The overall audit still requires perfect absolute exact and held-out access,
positive held-out margins, budget compliance, selectivity, controls, and
MOVE/RETURN gates on every seed. Relative transport-preservation diagnostics
are added but do not weaken or replace the absolute gates.

## Colab

Run `run_mfi_unified_l1_l5_v2_4_3.py`, then upload the matching source ZIP.
The broader training view set increases runtime. Allow about 100–150 minutes
on an A100 and reserve up to three hours for a cold environment.

## Direct run

```bash
python run_three_seed_audit.py --config config_audit.json --output results
```

## Evidence boundary

A pass would show access preservation under denser training-view coverage and
a new held-out family. It would not, by itself, show that expression
generalization improved relative to v2.4.1 because the held-out families have
different difficulty. This is not an untouched replication of the original
method. Its L4 component remains a
shared-state MOVE/RETURN access audit and does not replace the full L4
eight-endpoint, 28-relation matched-random geometry experiment. Cross-model
replication, global transport, capacity scaling, arbitrary program closure,
gradient-free operation, and autonomous instruction parsing remain untested.
