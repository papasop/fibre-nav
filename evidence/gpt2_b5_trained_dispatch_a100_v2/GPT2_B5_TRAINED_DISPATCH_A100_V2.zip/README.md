# GPT-2 B5 trained dispatch A100 V2 — development test

Run the entire `GPT2_B5_TRAINED_DISPATCH_A100_V2.py` in a Colab A100 cell. Stop any V1 worker first.

Input: a passed `gpt2_b4_minimal_causal_a100_results.zip`, a V1 **results** ZIP containing its original B4 parent, or a matching V2 results ZIP. Do not upload this source/launcher ZIP as input.

V2 trains a **separate GPT-2 controller** (seed 82932, frozen base/A, rank-16 LoRA-B) for 600 fixed steps. Its 440 teacher-labelled examples use 22 distinct-address XOR task tuples. The two evaluation tuples are excluded from training. The final controller is frozen and tested on 8 symbolic episodes with actual runtime feedback and all 14 action candidates; failed readiness stops before expensive physical writes. Readiness is a diagnostic, not physical memory evidence or an independent B5 result.

If readiness passes, actual B4 memory is evaluated on prepared, substituted, reset and restored states. The B4 memory model and original writing algorithm are preserved. The task permits writes to address 11 only; the runtime rejects other writes without replacing them. The controller gets the task and observed feedback, never an evaluation action label or precomputed action sequence. The external runtime computes XOR and performs gradient writes. This is a two-model learned-dispatch development test, not one-model self-modification, full B5 confirmation or Line C internal updates.

Controller checkpoints every 20 steps; original memory writer checkpoints every 5 steps. Atomic result ZIPs include source hashes, controller optimizer/weights, split, readiness traces, parent archive and physical operation records. Google Drive keeps only the latest 3 verified **V2** backups in its separate V2 folder. Existing B4/V1 backups are not changed. Unlimited session duration does not prevent Colab reclamation; resume from the last verified V2 ZIP.

No A100 training run was performed when preparing this package. Syntax compilation and 8 runtime/data-split tests passed. Controller convergence and physical gate acceptance must be measured by running it.
