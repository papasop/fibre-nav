# Intrinsic Picard fine-tuning v0.2.6

v0.2.6 is a no-retuning repeated-timing confirmation. It freezes the v0.2.5 target and selected learning rates (`AdamW=0.003`, cached Picard=`0.12`) and evaluates five entirely new seeds.

Each seed/arm executes the identical deterministic optimization trajectory five times. Reported time-to-target and fixed-budget time are repeat medians; the aggregate target-measurement window must be at least two seconds. Repeated endpoints and hit steps must match exactly, so repetition changes timing precision rather than optimization.

PASS requires both median time-to-equal-loss and fixed-budget speedups >=10%, accuracy non-inferiority within 0.5 percentage points, median endpoint-loss delta <=0.002, every endpoint-loss delta <=0.003, stable timing, and float64 response leakage <=1e-10. A pass remains task-specific.

Expected A100 runtime is roughly 12–18 minutes after feature extraction. Colab: upload and run `picard_finetune_v0_2_6_colab_launcher.py`, then upload `picard_finetune_demo_v0_2_6.zip` when prompted.
