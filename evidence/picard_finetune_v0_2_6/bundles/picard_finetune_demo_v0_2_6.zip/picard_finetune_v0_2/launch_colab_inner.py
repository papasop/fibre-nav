import subprocess,sys
raise SystemExit(subprocess.call([sys.executable,"-u","picard_finetune_benchmark_v0_2_6.py","--device","cuda","--outdir","/content/picard_v0_2_6_results","--data-root","/content/data"]))
