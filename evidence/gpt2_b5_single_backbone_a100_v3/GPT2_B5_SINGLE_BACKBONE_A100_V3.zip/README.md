# GPT-2 single-backbone B5 integration — A100 V3

Run the entire PY in Colab on A100. Stop any previous B5 worker first. Input may be the passed minimal B4 result, the passed V2 result (`gpt2_b5_trained_dispatch_a100_results.zip`), or matching V3 results for resume. Do not upload this launcher ZIP as input.

V3 creates exactly one GPT-2 model backbone. The original B4 adapter (`default`) holds the memory chart. A separate rank-16 `controller` adapter (new seed 82933) is trained from zero B for 600 fixed steps. An external runtime switches adapters exclusively: controller mode scores all 14 instructions; memory mode performs real reads and the unchanged B4 writer. Both adapters share the same frozen base model. This is a **single-backbone, partitioned-adapter integration**, not jointly active adapters or self-modification of one shared parameter chart.

The controller split is the same 22 training tuples and 2 withheld tuples as V2. Since the held-out tests have already been inspected, this remains development testing, not fresh confirmation. Readiness uses 8 symbolic XOR episodes. Failure stops before physical writes. Passing readiness proceeds to normal, stored-substitution, reset and restored physical runs. A fixed initial-task controller score probe is compared before/after each memory write (maximum absolute score drift gate 1e-5), and subsequent actual instruction selection is checked. Adapter isolation itself preserves the controller coordinates; this is not evidence for interference-free shared-chart writing.

Runtime adapter switching explicitly re-freezes all parameters except the selected LoRA-B chart during training/writes. Base and LoRA-A remain frozen. The external runtime still computes XOR and performs numerical gradient updates. No native attention-to-FFN weight writer, full B5 confirmation, independent multi-seed memory replication or Line C update internalisation is claimed.

Unlimited session duration; controller checkpoints every 20 steps, memory writer checkpoints every 5 steps. Atomic result ZIPs include checkpoints, sources, traces, identity and original B4 parent. Drive retains the latest 3 verified V3 backups in a new V3 folder without altering V2 archives. Colab reclamation can still interrupt; resume using the last verified V3 result ZIP.

Preparation validation: 10 stdlib routing/runtime/data-split tests and syntax/payload checks passed. Actual PEFT adapter integration and A100 convergence have not been executed locally; the run must verify them.
