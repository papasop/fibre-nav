# R12a-r2 pretrained GPT-2 response-loss Pareto sweep

R12a-r2 maps the deterministic pretrained GPT-2 response-loss frontier over
four tight global response budgets and 300 steps. It retains the r1 dropout and
response-repeatability repair. This remains a one-seed development sweep, not
a confirmation.

Arms: current-kernel identity, source-frozen identity, and response-budgeted
AdamW. The underperforming `alpha=0.25` metric arm is intentionally omitted.
Every arm shares the
pretrained checkpoint, intrinsic rank-4 LoRA chart, warm state, batches and
global response balls `1e-5`, `2e-5`, `5e-5`, and `1e-4`.

Run `COLAB_LAUNCHER_R12A_R2.py --quick` for a short environment smoke test. Restart
the runtime, run the launcher without `--quick`, and upload
`picard_gpt2_pretrained_dynamic_r12a_r2.zip`. Allow roughly 10-20 A100 minutes
plus first-download time.

The result archive is downloaded even when a numerical gate fails. Exit code
2 means fail-closed ineligibility, not necessarily a Python crash.
