# R12b pretrained GPT-2 multiseed development

R12b freezes the two budgets nominated by R12a-r2 and evaluates three new
development seeds (`32211`, `32217`, `32229`) for 300 steps. It retains the
dropout and response-repeatability repair. This is development, not confirmation.

Primary arms: current-kernel identity, source-frozen identity, and
response-budgeted AdamW. Unconstrained AdamW is recorded once per seed as a
diagnostic reference and is excluded from matched-budget gates.
Every arm shares the
pretrained checkpoint, intrinsic rank-4 LoRA chart, warm state, batches and
global response balls `2e-5` and `5e-5`.

Run `COLAB_LAUNCHER_R12B.py --quick` for a short environment smoke test. Restart
the runtime, run the launcher without `--quick`, and upload
`picard_gpt2_pretrained_dynamic_r12b.zip`. Allow roughly 35-55 A100 minutes
plus first-download time.

The result archive is downloaded even when a numerical gate fails. Exit code
2 means fail-closed ineligibility, not necessarily a Python crash.
