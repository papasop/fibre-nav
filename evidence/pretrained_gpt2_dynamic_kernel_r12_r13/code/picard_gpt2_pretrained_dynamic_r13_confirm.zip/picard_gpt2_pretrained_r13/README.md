# R13 pretrained GPT-2 untouched-seed confirmation

R13 freezes the complete R12b configuration and changes only to five untouched
seeds (`33211`, `33217`, `33229`, `33241`, `33253`). It is the confirmation
stage for the pretrained GPT-2 matched-response-budget ordering.

Primary arms: current-kernel identity, source-frozen identity, and
response-budgeted AdamW. Unconstrained AdamW is recorded once per seed as a
diagnostic reference and is excluded from matched-budget gates.
Every arm shares the
pretrained checkpoint, intrinsic rank-4 LoRA chart, warm state, batches and
global response balls `2e-5` and `5e-5`.

Run `COLAB_LAUNCHER_R13.py --quick` for a short environment smoke test. Restart
the runtime, run the launcher without `--quick`, and upload
`picard_gpt2_pretrained_dynamic_r13_confirm.zip`. Allow roughly 50-65 A100 minutes
plus first-download time.

The result archive is downloaded even when a numerical gate fails. Exit code
2 means fail-closed ineligibility, not necessarily a Python crash.
