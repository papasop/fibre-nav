#!/usr/bin/env python3
"""R13: untouched-seed pretrained GPT-2 dynamic-kernel confirmation.

Five untouched seeds test the complete configuration frozen after R12b. The
unconstrained AdamW arm is diagnostic only; it is excluded from budget gates.
"""
from __future__ import annotations

import argparse, hashlib, json, math, os, random, statistics, time, urllib.request
from pathlib import Path

PROTOCOL = "PRETRAINED_GPT2_LORA_DYNAMIC_KERNEL_R13_UNTOUCHED_CONFIRMATION"
MODEL_ID = "openai-community/gpt2"
DATA_URL = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"
DATA_SHA256 = "86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed"
SEEDS = (33211, 33217, 33229, 33241, 33253)
BUDGETS = (2e-5, 5e-5)
ARMS = ("current_identity", "source_identity", "adamw_budgeted", "adamw_unconstrained")
CONSTRAINED_ARMS = ("current_identity", "source_identity", "adamw_budgeted")


def seed_all(seed, torch):
    random.seed(seed); os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


def sync(torch, device):
    if device.type == "cuda": torch.cuda.synchronize(device)


def get_text(path: Path):
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(DATA_URL, path)
    raw = path.read_bytes(); got = hashlib.sha256(raw).hexdigest()
    if got != DATA_SHA256: raise RuntimeError(f"dataset SHA-256 mismatch: {got}")
    return raw.decode("utf-8")


def make_blocks(text, tokenizer, seq_len, torch):
    ids = torch.tensor(tokenizer.encode(text, add_special_tokens=False), dtype=torch.long)
    n = (len(ids)-1)//seq_len; ids = ids[:n*seq_len+1]
    x = ids[:-1].view(n,seq_len); y = ids[1:].view(n,seq_len)
    cut = int(.9*n); return (x[:cut],y[:cut]),(x[cut:],y[cut:])


def inject_chart_lora(model, chart_dim, rank, layers, torch):
    import torch.nn as nn
    class ChartLoRAConv1D(nn.Module):
        def __init__(self, base, coord, gen):
            super().__init__(); self.nf=base.nf; self.rank=rank; self.scale=1./rank
            self.weight=nn.Parameter(base.weight.detach().clone(),requires_grad=False)
            self.bias=nn.Parameter(base.bias.detach().clone(),requires_grad=False)
            nin,nout=self.weight.shape; count=rank*nin+nout*rank
            q,_=torch.linalg.qr(torch.randn(count,chart_dim,generator=gen,dtype=torch.float64),mode="reduced")
            self.register_buffer("basis",q.float()); basev=torch.zeros(count)
            basev[:rank*nin]=.02*torch.randn(rank*nin,generator=gen)
            self.register_buffer("base_vec",basev); self.coord=coord; self.nin=nin; self.nout=nout
        def forward(self,x):
            v=self.base_vec+self.basis@self.coord; k=self.rank*self.nin
            A=v[:k].view(self.rank,self.nin); B=v[k:].view(self.nout,self.rank)
            base=torch.addmm(self.bias,x.reshape(-1,x.size(-1)),self.weight).reshape(*x.shape[:-1],self.nf)
            return base+((x@A.T)@B.T)*self.scale
    for p in model.parameters(): p.requires_grad_(False)
    coord=nn.Parameter(torch.zeros(chart_dim)); model.register_parameter("intrinsic_lora_coordinate",coord)
    gen=torch.Generator(device="cpu").manual_seed(120317)
    chosen=list(range(model.config.n_layer-layers,model.config.n_layer))
    for i in chosen:
        old=model.transformer.h[i].attn.c_attn
        model.transformer.h[i].attn.c_attn=ChartLoRAConv1D(old,coord,gen)
    return coord,chosen


def batch_loss(model,xb,yb,idx,device,torch):
    x=xb[idx].to(device,non_blocking=True); y=yb[idx].to(device,non_blocking=True)
    logits=model(x).logits
    return torch.nn.functional.cross_entropy(logits.reshape(-1,logits.size(-1)),y.reshape(-1))


def grad(loss,coord,torch): return torch.autograd.grad(loss,coord)[0]


def response_values(model,anchors,device,torch):
    return torch.stack([batch_loss(model,x,y,i,device,torch).detach().double() for x,y,i in anchors])


def response_jacobian(model,coord,anchors,device,torch):
    return torch.stack([grad(batch_loss(model,x,y,i,device,torch),coord,torch).detach().double() for x,y,i in anchors])


def null_basis(J,torch):
    _,s,vh=torch.linalg.svd(J.double(),full_matrices=True)
    tol=max(J.shape)*torch.finfo(torch.float64).eps*(s.max() if s.numel() else 1.)
    rank=int((s>tol).sum()); N=vh[rank:].T.contiguous()
    if N.shape[1]<1: raise RuntimeError("empty numerical response kernel")
    P=N@N.T
    return N,{"rank":rank,"leakage":float((J@P).norm()/J.norm().clamp_min(1e-30)),
              "idempotence":float((P@P-P).norm()/P.norm().clamp_min(1e-30))}


def fisher(model,coord,metric_batches,N,device,damping,torch):
    h=[]
    for x,y,i in metric_batches:
        g=grad(batch_loss(model,x,y,i,device,torch),coord,torch).detach().double(); h.append(N.T@g)
    H=torch.stack(h); G=H.T@H/len(h); scale=(torch.trace(G)/G.shape[0]).clamp_min(1e-12)
    return G+damping*scale*torch.eye(G.shape[0],dtype=G.dtype,device=G.device)


def normalized(v): return v/v.norm().clamp_min(1e-30)


def projected_direction(g,N,G,arm,alpha,torch):
    h=N.T@g.double()
    if arm=="current_picard_a025":
        ev,Q=torch.linalg.eigh(G); u=Q@(ev.clamp_min(1e-12).pow(-alpha)*(Q.T@h))
    else: u=h
    return -normalized(N@u)


def frozen_indices(n,steps,bs,seed,torch):
    gen=torch.Generator(device="cpu").manual_seed(seed)
    return [torch.randint(0,n,(bs,),generator=gen) for _ in range(steps)]


def evaluate(model,xv,yv,device,torch,max_blocks,bs):
    model.eval(); vals=[]
    with torch.no_grad():
        for s in range(0,min(len(xv),max_blocks),bs):
            vals.append(float(batch_loss(model,xv,yv,torch.arange(s,min(s+bs,min(len(xv),max_blocks))),device,torch)))
    model.train(); return statistics.mean(vals)


def warm_start(model,coord,train,batches,args,device,torch):
    opt=torch.optim.AdamW([coord],lr=args.warm_lr,weight_decay=0.)
    for k in range(args.warm_steps):
        opt.zero_grad(set_to_none=True); batch_loss(model,*train,batches[k],device,torch).backward(); opt.step()
    return coord.detach().clone()


def run_arm(model,coord,warm,arm,budget,train,val,batches,anchors,metrics,args,device,torch,seed,out):
    xb,yb=train; xv,yv=val; coord.data.copy_(warm); model.train()
    J0=response_jacobian(model,coord,anchors,device,torch); N0,d0=null_basis(J0,torch); R0=response_values(model,anchors,device,torch)
    m=torch.zeros_like(coord,dtype=torch.float64); v=torch.zeros_like(m)
    trace=[]; lengths=[]; bts=[]; zero=0; maxdr=maxleak=maxidem=max_restore_repeat=0.; ranks=[]; geometry_seconds=0.; sync(torch,device); t0=time.perf_counter()
    for step in range(args.steps):
        loss=batch_loss(model,xb,yb,batches[args.warm_steps+step],device,torch); g=grad(loss,coord,torch).detach().double()
        sync(torch,device); tg=time.perf_counter()
        if arm=="source_identity": N,dg=N0,d0; G=None
        elif arm in ("adamw_budgeted","adamw_unconstrained"): N=G=None; dg=d0
        else:
            J=response_jacobian(model,coord,anchors,device,torch); N,dg=null_basis(J,torch)
            G=fisher(model,coord,metrics,N,device,args.damping,torch) if arm=="current_picard_a025" else None
        sync(torch,device); geometry_seconds+=time.perf_counter()-tg
        if arm in ("adamw_budgeted","adamw_unconstrained"):
            m=args.beta1*m+(1-args.beta1)*g; v=args.beta2*v+(1-args.beta2)*g.square()
            mh=m/(1-args.beta1**(step+1)); vh=v/(1-args.beta2**(step+1))
            proposal=-args.adamw_lr*mh/(vh.sqrt()+args.adamw_eps)
        else: proposal=args.lr*projected_direction(g,N,G,arm,args.alpha,torch)
        old=coord.detach().clone(); scale=1.; accepted=False; used=0
        if arm=="adamw_unconstrained":
            coord.data.add_(proposal.to(coord.dtype)); Rnew=response_values(model,anchors,device,torch); accepted=True
        else:
            for bt in range(args.max_backtracks+1):
                coord.data.copy_(old); coord.data.add_((scale*proposal).to(coord.dtype)); Rnew=response_values(model,anchors,device,torch)
                if float((Rnew-R0).norm())<=budget*(1+1e-8): accepted=True; used=bt; break
                scale*=.5
        if not accepted:
            coord.data.copy_(old); Ra=response_values(model,anchors,device,torch); Rb=response_values(model,anchors,device,torch)
            max_restore_repeat=max(max_restore_repeat,float((Ra-Rb).norm())); Rnew=Rb; scale=0.; used=args.max_backtracks+1; zero+=1
        drift=float((Rnew-R0).norm()); maxdr=max(maxdr,drift); lengths.append(float((scale*proposal).norm())); bts.append(used)
        maxleak=max(maxleak,dg["leakage"]); maxidem=max(maxidem,dg["idempotence"]); ranks.append(dg["rank"])
        if (step+1)%args.eval_interval==0 or step==args.steps-1:
            vl=evaluate(model,xv,yv,device,torch,args.val_blocks,args.batch_size)
            trace.append({"step":step+1,"validation_loss":vl,"global_response_drift":drift,"accepted_step_norm":lengths[-1]})
            print(f"[{arm} B={budget:.0e}] {step+1}/{args.steps} val={vl:.6f} drift={drift:.2e}",flush=True)
    sync(torch,device); elapsed=time.perf_counter()-t0
    rec={"seed":seed,"arm":arm,"budget":budget,"budget_constrained":arm in CONSTRAINED_ARMS,"final_validation_loss":trace[-1]["validation_loss"],
         "best_validation_loss":min(q["validation_loss"] for q in trace),"max_global_response_drift":maxdr,
         "zero_step_fraction":zero/args.steps,"median_accepted_step_norm":statistics.median(lengths),
         "accepted_steps":args.steps-zero,"max_restored_state_response_repeat_error":max_restore_repeat,
         "median_backtracks":statistics.median(bts),"max_projector_leakage":maxleak,"max_projector_idempotence":maxidem,
         "response_ranks":sorted(set(ranks)),"timed_seconds":elapsed,"geometry_seconds":geometry_seconds,"trace":trace}
    (out/f"{arm}_B{budget:.0e}_{seed}.json".replace("-","m")).write_text(json.dumps(rec,indent=2)+"\n"); return rec


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--device",default="cuda"); ap.add_argument("--outdir",default="r13_results"); ap.add_argument("--data-root",default="data")
    ap.add_argument("--steps",type=int,default=300); ap.add_argument("--warm-steps",type=int,default=30); ap.add_argument("--batch-size",type=int,default=4); ap.add_argument("--seq-len",type=int,default=64)
    ap.add_argument("--chart-dim",type=int,default=24); ap.add_argument("--lora-rank",type=int,default=4); ap.add_argument("--layers",type=int,default=2)
    ap.add_argument("--lr",type=float,default=.025); ap.add_argument("--warm-lr",type=float,default=.01); ap.add_argument("--adamw-lr",type=float,default=.01)
    ap.add_argument("--alpha",type=float,default=.25); ap.add_argument("--damping",type=float,default=.08); ap.add_argument("--beta1",type=float,default=.9); ap.add_argument("--beta2",type=float,default=.999); ap.add_argument("--adamw-eps",type=float,default=1e-8)
    ap.add_argument("--max-backtracks",type=int,default=14); ap.add_argument("--eval-interval",type=int,default=10); ap.add_argument("--val-blocks",type=int,default=24); ap.add_argument("--quick",action="store_true"); args=ap.parse_args()
    import torch
    from transformers import AutoTokenizer,GPT2LMHeadModel
    if args.device.startswith("cuda") and not torch.cuda.is_available(): raise RuntimeError("CUDA requested but unavailable")
    seeds=SEEDS[:1] if args.quick else SEEDS
    if args.quick: args.steps=20; args.warm_steps=8; args.val_blocks=8
    device=torch.device(args.device); out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)
    print(f"protocol={PROTOCOL} device={device} seeds={len(seeds)} mode={'quick_nonclaim' if args.quick else 'untouched_seed_confirmation'}",flush=True)
    text=get_text(Path(args.data_root)/"tinyshakespeare.txt"); tok=AutoTokenizer.from_pretrained(MODEL_ID); train,val=make_blocks(text,tok,args.seq_len,torch)
    records=[]; determinism=[]; started=time.time(); pretrained_ok=True; dropout_ok=True
    for si,seed in enumerate(seeds,1):
        seed_all(seed,torch); model=GPT2LMHeadModel.from_pretrained(MODEL_ID).to(device); model.config.use_cache=False
        pretrained_ok=pretrained_ok and model.config._name_or_path==MODEL_ID; dropout_modules=0
        for module in model.modules():
            if isinstance(module,torch.nn.Dropout): module.p=0.; dropout_modules+=1
        dropout_ok=dropout_ok and dropout_modules>0 and all(not isinstance(m,torch.nn.Dropout) or m.p==0 for m in model.modules())
        coord,layers=inject_chart_lora(model,args.chart_dim,args.lora_rank,args.layers,torch); model.to(device)
        batches=frozen_indices(len(train[0]),args.warm_steps+args.steps,args.batch_size,seed+11,torch)
        response_ids=[torch.arange(0,args.batch_size),torch.arange(args.batch_size,2*args.batch_size)]
        metric_ids=[torch.arange((2+i)*args.batch_size,(3+i)*args.batch_size) for i in range(4)]
        anchors=[(*train,i) for i in response_ids]; metrics=[(*train,i) for i in metric_ids]
        warm=warm_start(model,coord,train,batches,args,device,torch); coord.data.copy_(warm)
        repeat=[response_values(model,anchors,device,torch) for _ in range(3)]
        repeat_error=max(float((repeat[i]-repeat[0]).norm()) for i in range(1,len(repeat)))
        determinism.append({"seed":seed,"disabled_dropout_modules":dropout_modules,"fixed_state_response_repeat_error":repeat_error})
        print(f"[seed {si}/{len(seeds)}] {seed} warm complete repeat_error={repeat_error:.3e}",flush=True)
        if repeat_error>1e-12: raise RuntimeError("fixed-state response determinism preflight failed")
        for B in BUDGETS:
            for arm in ARMS:
                if arm=="adamw_unconstrained" and B!=BUDGETS[0]: continue
                records.append(run_arm(model,coord,warm,arm,B,train,val,batches,anchors,metrics,args,device,torch,seed,out))
        del model; torch.cuda.empty_cache()
    by={(r["seed"],r["budget"],r["arm"]):r for r in records}; budget_results=[]; seed_pairs=[]
    for B in BUDGETS:
        ac=[]; sc=[]; dual=0
        for seed in seeds:
            cur=by[seed,B,"current_identity"]; da=by[seed,B,"adamw_budgeted"]["final_validation_loss"]-cur["final_validation_loss"]; ds=by[seed,B,"source_identity"]["final_validation_loss"]-cur["final_validation_loss"]
            win=da>0 and ds>0; dual+=win; ac.append(da); sc.append(ds); seed_pairs.append({"seed":seed,"budget":B,"adamw_budgeted_minus_current":da,"source_minus_current":ds,"current_beats_both":win})
        budget_results.append({"budget":B,"median_adamw_budgeted_minus_current":statistics.median(ac),"median_source_minus_current":statistics.median(sc),"dual_win_seeds":dual,"supports_frozen_confirmation_gate":statistics.median(ac)>0 and statistics.median(sc)>0 and dual>=4})
    constrained=[r for r in records if r["arm"] in CONSTRAINED_ARMS]; supporting=sum(q["supports_frozen_confirmation_gate"] for q in budget_results)
    gates={"five_untouched_confirmation_seeds":len(seeds)==5,"pretrained_checkpoint_loaded":pretrained_ok,"all_dropout_modules_disabled":dropout_ok,"all_fixed_state_response_repeat_errors_at_most_1e_12":max(q["fixed_state_response_repeat_error"] for q in determinism)<=1e-12,"all_runs_finite":all(math.isfinite(r["final_validation_loss"]) for r in records),"all_constrained_global_budgets_respected":all(r["max_global_response_drift"]<=r["budget"]*(1+1e-8) for r in constrained),"all_restored_state_repeat_errors_at_most_1e_12":max(r["max_restored_state_response_repeat_error"] for r in records)<=1e-12,"float64_projector_leakage_at_most_1e_10":max(r["max_projector_leakage"] for r in records)<=1e-10,"projector_idempotence_at_most_1e_10":max(r["max_projector_idempotence"] for r in records)<=1e-10,"response_rank_constant":all(len(r["response_ranks"])==1 for r in records),"every_constrained_arm_budget_accepts_at_least_one_step":all(r["accepted_steps"]>=1 for r in constrained),"all_constrained_zero_step_fractions_below_0_95":all(r["zero_step_fraction"]<.95 for r in constrained),"both_budgets_support_frozen_confirmation_gate":supporting==len(BUDGETS)}
    eligible=all(v for k,v in gates.items() if k!="both_budgets_support_frozen_confirmation_gate"); confirmed=eligible and supporting==len(BUDGETS) and not args.quick
    summary={"protocol":PROTOCOL,"mode":"quick_nonclaim" if args.quick else "untouched_seed_confirmation","development_reference":"R12B_MULTISEED_DEVELOPMENT_CANDIDATE_SUPPORTED","model":MODEL_ID,"pretrained":True,"data_sha256":DATA_SHA256,"seeds":seeds,"budgets":BUDGETS,"primary_arms":CONSTRAINED_ARMS,"diagnostic_arms":["adamw_unconstrained"],"determinism":determinism,"frozen_configuration":{"steps":300,"warm_steps":30,"chart_dim":24,"lora_rank":4,"layers":2,"lr":.025,"warm_lr":.01,"adamw_lr":.01,"max_backtracks":14,"global_response_backtracking":True},"seed_pairs":seed_pairs,"budget_results":budget_results,"supporting_budget_count":supporting,"records":records,"gates":gates,"scientific_status":"R13_PRETRAINED_GPT2_CURRENT_KERNEL_BUDGETED_DUAL_ADVANTAGE_CONFIRMED" if confirmed else ("R13_QUICK_NONCLAIM" if args.quick else "R13_PRETRAINED_GPT2_CONFIRMATION_INCONCLUSIVE_FAIL_CLOSED"),"wall_seconds":time.time()-started,"claim_boundary":"Frozen five-seed confirmation within pretrained GPT-2, a shared 24-dimensional rank-4 LoRA chart, and two declared global response balls. The unconstrained AdamW arm is diagnostic and excluded from matched-budget gates. A positive result confirms current-kernel advantage over source-frozen and response-budgeted AdamW only; it does not establish superiority to unconstrained AdamW, semantic transfer, optimizer universality, or a Picard theorem."}
    (out/"run_summary.json").write_text(json.dumps(summary,indent=2)+"\n"); print(json.dumps(summary,indent=2)); return 0 if confirmed or args.quick else 2


if __name__=="__main__": raise SystemExit(main())
