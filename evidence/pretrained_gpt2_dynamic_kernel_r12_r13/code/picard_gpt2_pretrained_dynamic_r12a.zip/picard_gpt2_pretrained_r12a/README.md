# R12a pretrained GPT-2 dynamic-kernel preflight

R12a is a one-seed engineering and mechanism preflight that joins the R11
dynamic-kernel construction to a genuinely pretrained GPT-2 checkpoint. It is
not a confirmation and cannot support an optimizer-superiority claim.

Arms: current tempered-Picard (`alpha=0.25`), current-kernel identity,
source-frozen identity, and response-budgeted AdamW. Every arm shares the
pretrained checkpoint, intrinsic rank-4 LoRA chart, warm state, batches and
global response balls `1e-4` and `5e-4`.

Run `COLAB_LAUNCHER_R12A.py --quick` for a short environment smoke test. Restart
the runtime, run the launcher without `--quick`, and upload
`picard_gpt2_pretrained_dynamic_r12a.zip`. Expected A100 runtime is roughly
20-45 minutes; model and dataset download time is additional.

The result archive is downloaded even when a numerical gate fails. Exit code
2 means fail-closed ineligibility, not necessarily a Python crash.

