# Qwen 当前运算规则与数值路径诊断 CPU V6

V5 新候选在已完成的首轮16题中，候选分数12/16、严格自由输出2/16；历史对照15/16和14/16。
V6 根据已知失败设计一个固定开发候选：仅给当前运算的规则。没有训练、Adapter或参数记忆写入。
模型仍须计算输出，外部控制器负责按运算名称选规则。这不是自主指令编译，也不是GPT-2地址机制复现。

## Colab 使用

1. 将 `COLAB_LAUNCHER_QWEN_OPERATION_CPU_V6.py` 全文粘贴到 Colab 单元格运行。
2. 弹窗上传 `qwen_operation_cpu_v6.zip`。历史对照已内置，不需要旧结果。
3. 纯CPU、4线程、float32。首次安装固定依赖并下载模型，建议至少12GB可用内存。
4. 每点原子提交；16/32/48/64点保存并请求下载阶段包。停止或结束时下载主包与日志。
5. 默认不挂载 Drive；可设 USE_GOOGLE_DRIVE=True，挂载失败继续本地保存。

主结果：`/content/qwen_operation_cpu_v6/run/cpu_operation_rule_results.zip`
日志：`/content/qwen_operation_cpu_v6/QWEN_OPERATION_V6_SESSION_OUTPUT.txt`

```python
from pathlib import Path
from google.colab import files
p = Path('/content/qwen_operation_cpu_v6/run/cpu_operation_rule_results.zip')
if p.is_file():
    files.download(str(p))
else:
    print('尚未生成结果包，请检查本次运行日志。')
```

请确认浏览器下载完成；运行时销毁且未下载、未备份的结果无法保证恢复。
无需venv/ensurepip。独立python -I -S子进程避免notebook的-f参数干扰。

## 冻结设计

Qwen/Qwen3-1.7B，revision `70d244cc86ccca08cf5af4e1e306ecf908b1ad5e`。
CPU float32、4线程、SDPA、seed84917、关闭thinking，greedy最多128新token。
固定torch2.8.0 CPU、transformers4.56.2；其他版本见requirements_cpu.txt。

两组均为00/01/10/11 × OR/AND/XOR/A==B，共16题：

- historical：逐字保留V4极简提示及真实基线，包括错误和多余解释。
- selected_rule：在相同提示前只加当前操作对应的一句一般规则，四个输入使用同一句；不按错误案例分支。

四句规则与32条实际提示完整冻结在protocol.py和FROZEN_QUERIES.json。
原聊天模板与Answer前缀不变；实际tokenizer必须逐字复现冻结提示。
两组首轮32点后完整重复32点。每点都有自由生成、受限生成、3次原候选评分前向和2次数值诊断前向。
合计64检查点、128生成序列、192候选评分前向、128额外诊断前向。

## 格式与语义分开

自由输出必须去掉首尾空白后仅为一个0或1，不能截断；保留全部原文，不从解释提取答案。
受限输出第一步仅允许0和1，原logit不变、由模型选择；第二步由外部控制器强制EOS。
受限格式正确是控制器的保证，不是模型推理或自主停止能力。它不能改正错误答案。
主分数为未掩码下一token的0/1 log概率；bit+EOS仍只是次要诊断。

## V5 数值差异的诊断

V5实际出现6点跨路径差值超过1e-5，最大1.52587890625e-5；尚未证实原因。
V6保留原1e-5门槛，同时记录：

1. 原候选评分前向的两个原始logit（完整位置投影、use_cache=False）。
2. 受限生成同一次处理器调用内，掩码前后两个logit，要求完全相同且仅2个有限logit。
3. 同一提示、use_cache=False、logits_to_keep=1 的额外前向。
4. 同一提示、use_cache=True、logits_to_keep=1 的额外前向。

summary.json的numerical_diagnostic逐点报告：log-softmax消去误差、生成对原评分的gap差、末位置投影差、缓存开关差，以及生成对两个新增路径的差。
这些用于定位路径敏感性，不能单凭某一项接近就断言唯一根因；新路径不会替换原主评分。
新增诊断逐点重复并保存，但其变体差值只作诊断，不另外定义通过门槛。
同一次前向的掩码审计通过，也不能覆盖跨路径1e-5不通过。

## 固定通过条件

- 主候选未掩码分数16/16、运算对照14/14、输入对照12/12；gap绝对值≤1e-5弃权。
- 主候选严格自由生成16/16；受限模式另外报告。
- 两组全部重复：输出、token、有效配置一致；原评分与受限logit差≤1e-5。
- historical复现全部16条内置V4分数和自由输出。
- 所有点格式控制审计及未改变的跨路径1e-5审计通过，运行完整、环境一致。

`overall_pass`仅等于`native_free_pass`；受限成功不能替代。
`semantic_pass`与`constrained_interface_pass`也要求完整性审计通过；单组正确数始终单独可见。
`deployment_ready`、`unseen_expression_confirmation`、`formal_l6_pass`、`native_implicit_closure`始终false。
这是运行前冻结的开发协议，不声称外部预注册、未知表达确认、多seed或跨模型普遍性。
若通过，下一步仍需冻结新表达确认及独立部署验收，不能直接宣称可编程Qwen已经成立。

## 时间与续跑

按此前V4约43分钟、V5部分运行34点约24分钟估算，加上本版诊断，CPU暂估50–90分钟；安装下载另计，尚无V6预训练模型实测。长输出或慢机器可能超过范围。
默认90分钟预算，在检查点之间暂停；计时包括该次加载，进行中的点完成后才检查预算。

同一运行时重跑启动器上传源ZIP，会续用已提交记录。
新运行时上传同一源ZIP与一份最新V6主包或阶段包。旧版本结果不能混入。
源码、CPU标识、Python与依赖必须一致，否则停止而不混合记录。
若已有不同记录，使用新的--workdir；不会覆盖冲突记录。

```bash
python COLAB_LAUNCHER_QWEN_OPERATION_CPU_V6.py --source qwen_operation_cpu_v6.zip --minutes 90
```

## 工程检查

```bash
cd qwen_operation_cpu_v6
python -m unittest discover -p 'test_*.py' -v
```

启动器放在源目录父目录，或设置QWEN_OPERATION_V6_LAUNCHER为其绝对路径。
check_constraint_tiny.py用随机小Qwen3检查实际生成和数值诊断，不下载预训练权重。
本地工程环境与目标固定依赖版本不同，详见VALIDATION.md。工程测试通过不等于预训练Qwen实验通过。
哈希用于一致性核验，不能单独证明执行真实性。没有上传Hugging Face。
