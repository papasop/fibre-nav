"""Synthetic engineering tests; no pretrained Qwen evaluation."""
import copy,contextlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
import protocol as P
import run_cpu as R
ROOT=Path(__file__).resolve().parent;BASE=json.loads((ROOT/'baseline.json').read_text())
TABLE={'OR':'0111','AND':'0001','XOR':'0110','EQUAL':'1001'}
class Tok:
    def apply_chat_template(self,messages,**kwargs):
        assert kwargs==dict(tokenize=False,add_generation_prompt=True,enable_thinking=False)
        q=BASE['queries'][0];a,b=q['prompt'].split(q['content']);return a+messages[0]['content']+b[:-len('Answer: ')]
def plan():return P.schedule(P.make_queries(Tok(),BASE))
def good(item):
    q=item['query'];bit=TABLE[q['task']][P.PAIRS.index(q['pair'])];lp=[-.1,-3.] if bit=='0' else [-3.,-.1]
    out=dict(raw=bit,output_ids=[P.BIT_IDS[int(bit)],P.EOS_ID],truncated=False,effective_config={'do_sample':False})
    return dict(**copy.deepcopy(item),scores=dict(bit_logits=lp[:],bit_logp=lp,eos_given_bit_logp=[-.2,-.2]),free=copy.deepcopy(out),
        constrained=dict(**copy.deepcopy(out),policy=copy.deepcopy(P.POLICY),trace=dict(steps=[0,1],first_bit_logits=lp[:],masked_bit_logits=lp[:],finite_bit_count=2)),
        numeric={k:dict(settings=v.copy(),bit_logits=lp[:]) for k,v in __import__("numerical_diagnostic").SETTINGS.items()})
def fixture():
    p=plan();r=[good(i) for i in p];b=copy.deepcopy(BASE);b['records']=r[:16];return p,r,b
class ProtocolTests(unittest.TestCase):
    def test_frozen_rule_is_operation_only(self):
        qs=P.make_queries(Tok(),BASE);self.assertEqual(qs,json.loads((ROOT/'FROZEN_QUERIES.json').read_text()));self.assertEqual(len(qs),32);self.assertEqual(len(plan()),64)
        for i in range(16):self.assertEqual(qs[16+i]['content'],P.RULES[qs[i]['task']]+'\n'+qs[i]['content'])
        with patch.object(P,'truth',side_effect=AssertionError('answer leak')):P.make_queries(Tok(),BASE)
    def test_actual_v4_baseline_is_15_and_14(self):
        qs=P.make_queries(Tok(),BASE)[:16];g=P.group([dict(query=q,scores=r['scores'],free=r['free']) for q,r in zip(qs,BASE['records'])]);self.assertEqual((g['primary_correct'],g['free_correct']),(15,14))
        self.assertIn('Explanation:',BASE['records'][10]['free']['raw'])
    def test_full_native_and_bounded_pass_are_scoped(self):
        p,r,b=fixture();s=P.summarize(r,p,b);self.assertTrue(s['overall_pass']);self.assertTrue(s['native_free_pass']);self.assertTrue(s['constrained_interface_pass']);self.assertFalse(s['deployment_ready']);self.assertFalse(s['formal_l6_pass']);self.assertFalse(s['unseen_expression_confirmation'])
    def test_grammar_only_success_never_replaces_free(self):
        p,r,b=fixture()
        for x in r:
            if x['query']['block']=='selected_rule' and x['query']['pair']=='10' and x['query']['task']=='XOR':x['free']['raw']='1\nExplanation';x['free']['output_ids']=[16,100,151645]
        s=P.summarize(r,p,b);self.assertTrue(s['semantic_pass']);self.assertTrue(s['constrained_interface_pass']);self.assertFalse(s['native_free_pass']);self.assertFalse(s['overall_pass']);self.assertEqual(s['decision'],'CONSTRAINED_ONLY_PASS_NEEDS_CONFIRMATION')
    def test_grammar_cannot_fix_wrong_equality(self):
        p,r,b=fixture()
        for x in r:
            if x['query']['block']=='selected_rule' and x['query']['pair']=='00' and x['query']['task']=='EQUAL':
                x['scores']['bit_logp']=[-.1,-3.];x['free']['raw']='0';x['free']['output_ids']=[15,151645];x['constrained']['raw']='0';x['constrained']['output_ids']=[15,151645];x['constrained']['trace']['first_bit_logits']=[-.1,-3.];x['constrained']['trace']['masked_bit_logits']=[-.1,-3.]
        s=P.summarize(r,p,b);self.assertTrue(s['integrity_pass']);self.assertFalse(s['semantic_pass']);self.assertFalse(s['constrained_interface_pass']);self.assertEqual(s['constrained_groups']['selected_rule']['format_valid'],16);self.assertEqual(s['constrained_groups']['selected_rule']['correct'],15)
    def test_constraint_selection_or_gap_mismatch_blocks_pass(self):
        for kind in ('selection','gap','tokens'):
            p,r,b=fixture();c=r[16]['constrained']
            if kind=='selection':c['raw']='1';c['output_ids']=[16,151645]
            elif kind=='gap':c['trace']['first_bit_logits'][0]+=.001
            else:c['output_ids']=[15,42,151645]
            self.assertFalse(P.summarize(r,p,b)['overall_pass'])
    def test_missing_or_altered_policy_rejected(self):
        p,r,b=fixture();del r[0]['constrained']
        with self.assertRaisesRegex(ValueError,'MISSING_CONSTRAINED'):P.summarize(r,p,b)
        p,r,b=fixture();r[0]['constrained']['policy']['max_output_tokens']=3
        with self.assertRaisesRegex(ValueError,'CONSTRAINT_POLICY'):P.summarize(r,p,b)
    def test_numeric_does_not_relax_original_gate(self):
        p,r,b=fixture();row=r[16]
        row['constrained']['trace']['first_bit_logits'][0]+=1.2e-5
        row['constrained']['trace']['masked_bit_logits']=row['constrained']['trace']['first_bit_logits'][:]
        s=P.summarize(r,p,b)
        self.assertFalse(s['overall_pass']);self.assertFalse(s['numerical_diagnostic']['gate_changed'])
        self.assertTrue(P.constrained_score(row)['same_forward_mask_pass'])
    def test_mask_mutation_and_numeric_omission_detected(self):
        p,r,b=fixture();r[0]['constrained']['trace']['masked_bit_logits'][0]+=.01
        self.assertFalse(P.summarize(r,p,b)['overall_pass'])
        p,r,b=fixture();del r[0]['numeric']
        with self.assertRaises(KeyError):P.summarize(r,p,b)
        p,r,b=fixture();r[0]['numeric']['last_cache']['settings']['use_cache']=False
        with self.assertRaisesRegex(ValueError,'NUMERIC_VARIANT_SETTINGS'):P.summarize(r,p,b)
    def test_full_regression_is_required(self):
        p,r,b=fixture()
        for x in r:
            if x['query']['block']=='selected_rule' and x['query']['pair']=='11' and x['query']['task']=='OR':x['free']['raw']='0'
        s=P.summarize(r,p,b);self.assertTrue(s['semantic_pass']);self.assertFalse(s['overall_pass'])
    def test_environment_replays_and_missing_points_fail_closed(self):
        p,r,b=fixture()
        for n in (0,16,32,63):self.assertFalse(P.summarize(r[:n],p,b)['overall_pass'])
        self.assertFalse(P.summarize(r,p,b,False)['overall_pass'])
        r[-1]['constrained']['effective_config']['do_sample']=True;self.assertFalse(P.summarize(r,p,b)['overall_pass'])
    def test_invalid_score_and_record_shapes(self):
        p,r,b=fixture()
        for rows in (r+[r[0]],r[1:],r[:8]+r[9:]):
            with self.assertRaises(ValueError):P.summarize(rows,p,b)
        for bad in ([float('nan'),-1.],[0.,0.],[.1,-2.]):
            row=good(p[0]);row['scores']['bit_logp']=bad
            with self.assertRaises(ValueError):P.score(row)
        row=good(p[0]);row['scores']['bit_logp']=[-1.,-1.];self.assertIsNone(P.score(row)['primary_prediction'])
    def test_full_controller_checkpoint_hashes_and_noop_resume(self):
        p,r,b=fixture();items={x['query']['prompt']:x for x in r[:32]};calls=[]
        def evaluate(prompt):calls.append(prompt);return copy.deepcopy({k:items[prompt][k] for k in ('free','scores','constrained','numeric')})
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            out=Path(d)/'run';out.mkdir();s=R.execute(out,p,b,evaluate,True);self.assertTrue(s['overall_pass']);self.assertEqual(len(calls),64)
            R.execute(out,p,b,lambda prompt:self.fail('already committed'),True)
            for n in (16,32,48,64):self.assertTrue((out.parent/f'run_{n:03d}_results.zip').exists())
            with zipfile.ZipFile(out.parent/'run_results.zip') as z:
                m=json.loads(z.read('run/RESULT_MANIFEST.json'))
                for n,h in m.items():self.assertEqual(P.sha(z.read('run/'+n)),h)
    def test_interrupted_point_and_resume(self):
        p,r,b=fixture();items={x['query']['prompt']:x for x in r[:32]};n=0
        def evaluate(prompt):
            nonlocal n
            if n==17:raise RuntimeError('between free and constrained')
            n+=1;return copy.deepcopy({k:items[prompt][k] for k in ('free','scores','constrained','numeric')})
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            out=Path(d)
            with self.assertRaises(RuntimeError):R.execute(out,p,b,evaluate,True)
            self.assertEqual(len(R.saved_records(out,p)),17)
            s=R.execute(out,p,b,lambda prompt:copy.deepcopy({k:items[prompt][k] for k in ('free','scores','constrained','numeric')}),True);self.assertTrue(s['overall_pass'])
            with self.assertRaises(R.Pause):R.execute(Path(d)/'empty',p,b,lambda prompt:self.fail('expired'),True,deadline=0)
if __name__=='__main__':unittest.main(verbosity=2)
