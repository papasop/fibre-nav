"""Frozen post-V5 selected-operation interface and unchanged numerical gate."""
import hashlib,json,math
MODEL='Qwen/Qwen3-1.7B';REVISION='70d244cc86ccca08cf5af4e1e306ecf908b1ad5e'
ID='QWEN_OPERATION_CPU_V6'
PAIRS=('00','01','10','11');OPS=('OR','AND','XOR','EQUAL');BLOCKS=('historical','selected_rule')
TOTAL=64;TOL=1e-5;BIT_IDS=(15,16);EOS_ID=151645
RULES={
 'OR':'For OR, output 1 when at least one input bit is 1, otherwise output 0.',
 'AND':'For AND, output 1 when both input bits are 1, otherwise output 0.',
 'XOR':'For XOR, output 1 when the two input bits have different values, otherwise output 0.',
 'EQUAL':'For A == B, output 1 when the two input bits have the same value, otherwise output 0.'}
POLICY=dict(decoder='bit_then_eos',allowed_token_ids=list(BIT_IDS),forced_eos_token_id=EOS_ID,max_output_tokens=2)
CONFIG=dict(id=ID,model=MODEL,revision=REVISION,device='cpu',dtype='float32',threads=4,attention='sdpa',seed=84917,
 primary_interface='selected_rule',blocks=list(BLOCKS),cases_per_block=16,checkpoints=TOTAL,
 free_generations=64,constrained_generations=64,total_generations=128,candidate_forward_calls=192,numerical_diagnostic_forward_calls=128,
 tie_tolerance_nats=TOL,replay_score_atol=TOL,constraint_gap_atol=TOL,full_repetition_per_block=16,
 constraint_policy=POLICY,training_steps=0,memory_write_operations=0,adapter_count=0,
 scope='Post-V5 development. An external controller selects one fixed definition by operation name only; the same rule is used for all four input pairs. No answer lookup or input-specific repair. The model does not autonomously compile instructions. Numeric variants are diagnostic only; the original cross-path 1e-5 gate is unchanged. Each fixed prompt uses free generation and bit-then-EOS grammar, separately reported. Grammar enforces syntax, not truth: first bit chosen from unchanged model logits; EOS is externally forced. All16 cases per arm and full repeats. No training, neural-memory input, independent held-out confirmation or deployment claim.')

def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def truth(pair,op):
    a,b=map(int,pair)
    if op=='OR':return str(a|b)
    if op=='AND':return str(a&b)
    if op=='XOR':return str(a^b)
    if op=='EQUAL':return str(int(a==b))
    raise ValueError('OP')

def make_queries(tok,baseline):
    old=baseline['queries'];expected=[(p,o) for p in PAIRS for o in OPS]
    if [(q['pair'],q['task']) for q in old]!=expected:raise ValueError('HISTORICAL_INVENTORY')
    qs=[]
    for block in BLOCKS:
        for i,(pair,op) in enumerate(expected):
            content=('' if block=='historical' else RULES[op]+'\n')+old[i]['content']
            prompt=tok.apply_chat_template([dict(role='user',content=content)],tokenize=False,add_generation_prompt=True,enable_thinking=False)+'Answer: '
            if block=='historical' and prompt!=old[i]['prompt']:raise ValueError('HISTORICAL_PROMPT_CHANGED')
            qs.append(dict(id=f'{block}-{pair}-{op}',block=block,pair=pair,task=op,content=content,prompt=prompt))
    return qs

def schedule(queries):
    if [(q['block'],q['pair'],q['task']) for q in queries]!=[(b,p,o) for b in BLOCKS for p in PAIRS for o in OPS]:raise ValueError('QUERY_INVENTORY')
    plan=[dict(run_id=q['id'],repeat=False,query=q) for q in queries]+[dict(run_id=q['id']+'-repeat',repeat=True,query=q) for q in queries]
    assert len(plan)==TOTAL
    return plan

def score(record):
    scores=record['scores'];a=scores['bit_logp'];b=scores['eos_given_bit_logp']
    if len(a)!=2 or len(b)!=2 or not all(math.isfinite(x) and x<=0 for x in a+b):raise ValueError('NONFINITE_OR_INVALID_SCORES')
    if sum(math.exp(x) for x in a)>1+1e-8:raise ValueError('INVALID_PROBABILITY_MASS')
    gap=a[1]-a[0];second=a[1]+b[1]-a[0]-b[0]
    pred=None if abs(gap)<=TOL else str(int(gap>0));pred2=None if abs(second)<=TOL else str(int(second>0))
    raw=record['free']['raw'].strip();free=raw if raw in ('0','1') and not record['free']['truncated'] else None
    q=record['query'];expected=truth(q['pair'],q['task'])
    return dict(pair=q['pair'],task=q['task'],expected=expected,primary_prediction=pred,free_prediction=free,secondary_prediction=pred2,
       primary_correct=pred==expected,free_correct=free==expected,secondary_correct=pred2==expected,free_format_valid=free is not None,signed_margin=(1 if expected=='1' else -1)*gap,gap=gap)

def group(records):
    if [(r['query']['pair'],r['query']['task']) for r in records]!=[(p,o) for p in PAIRS for o in OPS]:raise ValueError('GROUP_INVENTORY')
    rs=[score(r) for r in records];lookup={(r['pair'],r['task']):r for r in rs};oe=[];ie=[]
    def ok(a,b):return a['primary_correct'] and b['primary_correct'] and a['primary_prediction']!=b['primary_prediction']
    for p in PAIRS:
        for i,o in enumerate(OPS):
            for other in OPS[i+1:]:
                if truth(p,o)!=truth(p,other):oe.append(ok(lookup[p,o],lookup[p,other]))
        for c in range(2):
            other=p[:c]+str(1-int(p[c]))+p[c+1:]
            if other>p:
                for o in OPS:
                    if truth(p,o)!=truth(other,o):ie.append(ok(lookup[p,o],lookup[other,o]))
    assert len(oe)==14 and len(ie)==12
    return dict(n=16,primary_correct=sum(r['primary_correct'] for r in rs),free_correct=sum(r['free_correct'] for r in rs),secondary_correct=sum(r['secondary_correct'] for r in rs),operation_contrasts_passed=sum(oe),input_contrasts_passed=sum(ie),pass_gate=all(r['primary_correct'] and r['free_correct'] for r in rs) and all(oe+ie),rows=rs)

def compare(a,b):
    if len(a)!=len(b) or not a:raise ValueError('REPEAT_INVENTORY')
    delta=max(abs(x-y) for r,t in zip(a,b) for k in ('bit_logp','eos_given_bit_logp') for x,y in zip(r['scores'][k],t['scores'][k]))
    free=all(r['free']['output_ids']==t['free']['output_ids'] and r['free']['raw']==t['free']['raw'] and r['free']['truncated']==t['free']['truncated'] for r,t in zip(a,b))
    cfg=all(r['free']['effective_config']==t['free']['effective_config'] for r,t in zip(a,b))
    return dict(score_pass=delta<=TOL,free_pass=free,decode_config_match=cfg,max_abs_score_delta=delta,pass_gate=delta<=TOL and free and cfg)

def constrained_score(record):
    s=score(record);c=record['constrained']
    if c['policy']!=POLICY:raise ValueError('CONSTRAINT_POLICY_CHANGED')
    trace=c['trace'];logits=trace['first_bit_logits']
    if len(logits)!=2 or not all(math.isfinite(x) for x in logits):raise ValueError('INVALID_CONSTRAINT_LOGITS')
    raw=c['raw'].strip();pred=raw if raw in ('0','1') else None
    valid=pred is not None and c['output_ids']==[BIT_IDS[int(pred)],EOS_ID] and not c['truncated'] and trace['steps']==[0,1]
    traced_choice=str(int(logits[1]>logits[0]))
    gap_delta=abs((logits[1]-logits[0])-s['gap'])
    agree=s['primary_prediction'] is None or pred==s['primary_prediction']
    after=trace.get('masked_bit_logits')
    same_forward=after==logits and trace.get('finite_bit_count')==2
    audit=bool(valid and pred==traced_choice and agree and gap_delta<=TOL and same_forward)
    return dict(constrained_prediction=pred,constrained_correct=bool(valid and pred==s['expected']),constrained_format_valid=valid,
        gap_abs_delta=gap_delta,same_forward_mask_pass=same_forward,selection_matches_primary=None if s['primary_prediction'] is None else agree,constraint_audit_pass=audit)

def constrained_group(records):
    g=group(records);rows=[dict(pair=r['query']['pair'],task=r['query']['task'],**constrained_score(r)) for r in records]
    semantic=g['primary_correct']==16 and g['operation_contrasts_passed']==14 and g['input_contrasts_passed']==12
    return dict(n=16,correct=sum(r['constrained_correct'] for r in rows),format_valid=sum(r['constrained_format_valid'] for r in rows),
        audit_pass=all(r['constraint_audit_pass'] for r in rows),pass_gate=semantic and all(r['constrained_correct'] and r['constraint_audit_pass'] for r in rows),rows=rows)

def compare_constrained(a,b):
    if len(a)!=len(b) or not a:raise ValueError('REPEAT_INVENTORY')
    same=all(all(r['constrained'][k]==t['constrained'][k] for k in ('raw','output_ids','truncated','effective_config','policy')) and r['constrained']['trace']['steps']==t['constrained']['trace']['steps'] for r,t in zip(a,b))
    delta=max(abs(x-y) for r,t in zip(a,b) for x,y in zip(r['constrained']['trace']['first_bit_logits'],t['constrained']['trace']['first_bit_logits']))
    return dict(output_config_pass=same,max_abs_logit_delta=delta,pass_gate=same and delta<=TOL)

def summarize(records,plan,baseline,environment_match=True):
    if len(plan)!=TOTAL:raise ValueError('SCHEDULE_INVENTORY')
    if len({r['run_id'] for r in records})!=len(records):raise ValueError('DUPLICATE_RECORD')
    if len(records)>len(plan):raise ValueError('EXTRA_RECORDS')
    from numerical_diagnostic import audit_numeric
    audits=[];numerics=[]
    for r,p in zip(records,plan):
        if any(r[k]!=p[k] for k in ('run_id','repeat','query')):raise ValueError('QUERY_OR_ORDER_CHANGED')
        score(r)
        if 'constrained' not in r:raise ValueError('MISSING_CONSTRAINED_OUTPUT')
        audits.append(constrained_score(r)['constraint_audit_pass'])
        numerics.append(audit_numeric(r))
    gs={};cgs={};reps={};creps={}
    for b in BLOCKS:
        a=[r for r in records if r['query']['block']==b and not r['repeat']]
        repeated=[r for r in records if r['query']['block']==b and r['repeat']]
        if len(a)==16:gs[b]=group(a);cgs[b]=constrained_group(a)
        if len(repeated)==16:reps[b]=dict(n=16,**compare(a,repeated));creps[b]=dict(n=16,**compare_constrained(a,repeated))
    historical=[r for r in records if r['query']['block']=='historical' and not r['repeat']]
    hist=compare(historical,baseline['records']) if len(historical)==16 else None
    complete=len(records)==TOTAL
    constraint_audit=complete and all(audits)
    integrity=bool(complete and environment_match and hist and hist['pass_gate'] and len(reps)==2 and all(r['pass_gate'] for r in reps.values()) and len(creps)==2 and all(r['pass_gate'] for r in creps.values()) and constraint_audit)
    primary=gs.get('selected_rule',{})
    semantic=bool(integrity and primary.get('primary_correct')==16 and primary.get('operation_contrasts_passed')==14 and primary.get('input_contrasts_passed')==12)
    native=bool(semantic and primary.get('pass_gate',False));bounded=bool(semantic and cgs.get('selected_rule',{}).get('pass_gate',False))
    decision='INCOMPLETE'
    if complete:
        decision='REPLAY_ENVIRONMENT_OR_CONSTRAINT_MISMATCH' if not integrity else 'NATIVE_FREE_DIAGNOSTIC_PASS_NEEDS_CONFIRMATION' if native else 'CONSTRAINED_ONLY_PASS_NEEDS_CONFIRMATION' if bounded else 'OPERATION_OR_REGRESSION_GAP_REMAINS'
    return dict(protocol_id=ID,completed=len(records),expected=TOTAL,complete=complete,groups=gs,constrained_groups=cgs,
        repeats=reps,constrained_repeats=creps,historical_replay=hist,environment_match=environment_match,constraint_audit_pass=constraint_audit,integrity_pass=integrity,
        numerical_diagnostic=dict(n=len(numerics),rows=numerics,original_cross_path_gate_atol=TOL,gate_changed=False),
        semantic_pass=semantic,native_free_pass=native,constrained_interface_pass=bounded,overall_pass=native,
        overall_pass_definition='Selected-operation-rule interface: all16 unmasked candidate scores and strict free outputs correct,14 operation and12 input contrasts, full dual-mode repeats, historical replay and constraint audits. Constrained success never substitutes for free success.',
        decision=decision,deployment_ready=False,unseen_expression_confirmation=False,formal_l6_pass=False,native_implicit_closure=False,
        training_steps=0,memory_write_operations=0,adapter_count=0,scope=CONFIG['scope'])
